﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareOneProject
{
    public partial class partModifyForm : Form
    {
        private mainForm mform;
        
        public partModifyForm(mainForm mf)
        {
            InitializeComponent();
            this.mform = mf;
        }

        private void btnPartModCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPartModSave_Click(object sender, EventArgs e)
        {
            int partIDResult;
            int partInventResult;
            int partMaxResult;
            int partMinResult;
            int partMachIdResult;

            string namePattern = @"^[a-zA-Z]+$";
            string compPattern = "^[a-zA-Z]+(\\s[a-zA-Z]+)?$";
            string pricePattern = "[0-9]+\\.?[0-9,]*";

            bool isNameValid = Regex.IsMatch(txtBoxModPartName.Text, namePattern);
            bool isPriceValid = Regex.IsMatch(txtBoxModPartPrice.Text, pricePattern);
            bool isCompValid = Regex.IsMatch(txtBoxModPartMachId.Text, compPattern);

            if (string.IsNullOrEmpty(txtBoxModPartId.Text)) //Validation for mod part ID
            {
                errProvModPartId.SetError(txtBoxModPartId, "Part ID is required");
                return;
            }
            else if (!int.TryParse(txtBoxModPartId.Text, out partIDResult))
            {
                errProvModPartId.SetError(txtBoxModPartId, "Part ID must be a whole number");
                return;
            }
            else
            {
                errProvModPartId.SetError(txtBoxModPartId, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModPartName.Text)) //Validation for mod part Name
            {
                errProvModPartName.SetError(txtBoxModPartName, "Part Name is required");
                return;
            }
            else if (!isNameValid)
            {
                errProvModPartName.SetError(txtBoxModPartName, "Part Name must only be letters");
                return;
            }
            else
            {
                errProvModPartName.SetError(txtBoxModPartName, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModPartInvent.Text)) //Validation for mod part Inventory
            {
                errProvModPartInvent.SetError(txtBoxModPartInvent, "Part Inventory is required");
                return;
            }
            else if (!int.TryParse(txtBoxModPartInvent.Text, out partInventResult))
            {
                errProvModPartInvent.SetError(txtBoxModPartInvent, "Inventory must be a whole number");
                return;
            }
            else
            {
                errProvModPartInvent.SetError(txtBoxModPartInvent, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModPartPrice.Text)) //Validation for mod part Price
            {
                errProvModPartPrice.SetError(txtBoxModPartPrice, "Part Price is required");
                return;
            }
            else if (!isPriceValid)
            {
                errProvModPartPrice.SetError(txtBoxModPartPrice, "Price amount must be a decimal or use a comma");
                return;
            }
            else
            {
                errProvModPartPrice.SetError(txtBoxModPartPrice, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModPartMax.Text)) //Validation for mod part Max
            {
                errProvModPartMax.SetError(txtBoxModPartMax, "Part Max is required");
                return;
            }
            else if (!int.TryParse(txtBoxModPartMax.Text, out partMaxResult))
            {
                errProvModPartMax.SetError(txtBoxModPartMax, "Part Max must be a whole number");
                return;
            }
            else if (partInventResult > partMaxResult)
            {
                errProvModPartInvent.SetError(txtBoxModPartInvent, "Part Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvModPartMax.SetError(txtBoxModPartMax, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModPartMin.Text)) //Validation for mod part Min
            {
                errProvModPartMin.SetError(txtBoxModPartMin, "Part Min is required");
                return;
            }
            else if (!int.TryParse(txtBoxModPartMin.Text, out partMinResult))
            {
                errProvModPartMin.SetError(txtBoxModPartMin, "Part Min must be a whole number");
                return;
            }
            else if (partMinResult >= partMaxResult)
            {
                errProvModPartMin.SetError(txtBoxModPartMin, "Part Min must be lower than part Max"); //Validate that Min is lower than Max
                return;
            }
            else if (partInventResult < partMinResult)
            {
                errProvModPartInvent.SetError(txtBoxModPartInvent, "Part Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvModPartMin.SetError(txtBoxModPartMin, string.Empty);
            }

            if (!rdoBtnOutSModify.Checked)
            {

                if (string.IsNullOrEmpty(txtBoxModPartMachId.Text)) //Validation for add part Machine Id
                {
                    errProvModPartMachId.SetError(txtBoxModPartMachId, "Part Machine ID is required");
                    return;
                }
                else if (!int.TryParse(txtBoxModPartMachId.Text, out partMachIdResult))
                {
                    errProvModPartMachId.SetError(txtBoxModPartMachId, "Machine ID must be a whole number");        //FIXED. Issue was the nested if and needing to make unique Regex
                    return;
                }
                else
                {
                    errProvModPartMachId.SetError(txtBoxModPartMachId, string.Empty);
                }
            }

            if (!rdoBtnInHModify.Checked)
            {
                if (string.IsNullOrEmpty(txtBoxModPartMachId.Text)) //Validation for add part Company Name
                {
                    errProvModPartMachId.SetError(txtBoxModPartMachId, "Company Name is required");
                    return;
                }
                else if (!isCompValid)
                {
                    errProvModPartMachId.SetError(txtBoxModPartMachId, "Company Name must only be letters");
                    return;
                }
                else
                {
                    errProvModPartMachId.SetError(txtBoxModPartMachId, string.Empty);
                }
            }          

            mform.dataGridView1.CurrentRow.Cells[0].Value = txtBoxModPartId.Text; //THIS IS IT!!!! The Code that allows you to modify the Datagridview
            mform.dataGridView1.CurrentRow.Cells[1].Value = txtBoxModPartName.Text;
            mform.dataGridView1.CurrentRow.Cells[2].Value = txtBoxModPartInvent.Text;
            mform.dataGridView1.CurrentRow.Cells[3].Value = txtBoxModPartPrice.Text;
            mform.dataGridView1.CurrentRow.Cells[4].Value = txtBoxModPartMax.Text;
            mform.dataGridView1.CurrentRow.Cells[5].Value = txtBoxModPartMin.Text;
            mform.dataGridView1.CurrentRow.Cells[6].Value = txtBoxModPartMachId.Text;


            this.Close();
        }

        private void rdoBtnInHModify_CheckedChanged(object sender, EventArgs e)
        {
            lblPartModMachId.Text = "Machine ID";
        }

        private void rdoBtnOutSModify_CheckedChanged(object sender, EventArgs e)
        {
            lblPartModMachId.Text = "Company Name";
        }
    }
}
