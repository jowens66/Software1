﻿namespace SoftwareOneProject
{
    partial class partModifyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblModifyPartTitle = new System.Windows.Forms.Label();
            this.rdoBtnInHModify = new System.Windows.Forms.RadioButton();
            this.rdoBtnOutSModify = new System.Windows.Forms.RadioButton();
            this.lblPartModId = new System.Windows.Forms.Label();
            this.lblPartModName = new System.Windows.Forms.Label();
            this.lblPartModInvent = new System.Windows.Forms.Label();
            this.lblPartModPrice = new System.Windows.Forms.Label();
            this.lblPartModMax = new System.Windows.Forms.Label();
            this.lblPartModMin = new System.Windows.Forms.Label();
            this.lblPartModMachId = new System.Windows.Forms.Label();
            this.btnPartModSave = new System.Windows.Forms.Button();
            this.txtBoxModPartId = new System.Windows.Forms.TextBox();
            this.txtBoxModPartName = new System.Windows.Forms.TextBox();
            this.txtBoxModPartInvent = new System.Windows.Forms.TextBox();
            this.txtBoxModPartPrice = new System.Windows.Forms.TextBox();
            this.txtBoxModPartMachId = new System.Windows.Forms.TextBox();
            this.txtBoxModPartMax = new System.Windows.Forms.TextBox();
            this.txtBoxModPartMin = new System.Windows.Forms.TextBox();
            this.btnPartModCancel = new System.Windows.Forms.Button();
            this.errProvModPartId = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModPartName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModPartInvent = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModPartPrice = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModPartMax = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModPartMin = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModPartMachId = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartInvent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartMachId)).BeginInit();
            this.SuspendLayout();
            // 
            // lblModifyPartTitle
            // 
            this.lblModifyPartTitle.AutoSize = true;
            this.lblModifyPartTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModifyPartTitle.Location = new System.Drawing.Point(8, 9);
            this.lblModifyPartTitle.Name = "lblModifyPartTitle";
            this.lblModifyPartTitle.Size = new System.Drawing.Size(85, 16);
            this.lblModifyPartTitle.TabIndex = 0;
            this.lblModifyPartTitle.Text = "Modify Part";
            // 
            // rdoBtnInHModify
            // 
            this.rdoBtnInHModify.AutoSize = true;
            this.rdoBtnInHModify.Checked = true;
            this.rdoBtnInHModify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoBtnInHModify.Location = new System.Drawing.Point(127, 9);
            this.rdoBtnInHModify.Name = "rdoBtnInHModify";
            this.rdoBtnInHModify.Size = new System.Drawing.Size(76, 17);
            this.rdoBtnInHModify.TabIndex = 1;
            this.rdoBtnInHModify.TabStop = true;
            this.rdoBtnInHModify.Text = "In-House";
            this.rdoBtnInHModify.UseVisualStyleBackColor = true;
            this.rdoBtnInHModify.CheckedChanged += new System.EventHandler(this.rdoBtnInHModify_CheckedChanged);
            // 
            // rdoBtnOutSModify
            // 
            this.rdoBtnOutSModify.AutoSize = true;
            this.rdoBtnOutSModify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoBtnOutSModify.Location = new System.Drawing.Point(234, 9);
            this.rdoBtnOutSModify.Name = "rdoBtnOutSModify";
            this.rdoBtnOutSModify.Size = new System.Drawing.Size(90, 17);
            this.rdoBtnOutSModify.TabIndex = 2;
            this.rdoBtnOutSModify.Text = "Outsourced";
            this.rdoBtnOutSModify.UseVisualStyleBackColor = true;
            this.rdoBtnOutSModify.CheckedChanged += new System.EventHandler(this.rdoBtnOutSModify_CheckedChanged);
            // 
            // lblPartModId
            // 
            this.lblPartModId.AutoSize = true;
            this.lblPartModId.Location = new System.Drawing.Point(124, 75);
            this.lblPartModId.Name = "lblPartModId";
            this.lblPartModId.Size = new System.Drawing.Size(18, 13);
            this.lblPartModId.TabIndex = 3;
            this.lblPartModId.Text = "ID";
            // 
            // lblPartModName
            // 
            this.lblPartModName.AutoSize = true;
            this.lblPartModName.Location = new System.Drawing.Point(104, 102);
            this.lblPartModName.Name = "lblPartModName";
            this.lblPartModName.Size = new System.Drawing.Size(35, 13);
            this.lblPartModName.TabIndex = 4;
            this.lblPartModName.Text = "Name";
            // 
            // lblPartModInvent
            // 
            this.lblPartModInvent.AutoSize = true;
            this.lblPartModInvent.Location = new System.Drawing.Point(91, 134);
            this.lblPartModInvent.Name = "lblPartModInvent";
            this.lblPartModInvent.Size = new System.Drawing.Size(51, 13);
            this.lblPartModInvent.TabIndex = 5;
            this.lblPartModInvent.Text = "Inventory";
            // 
            // lblPartModPrice
            // 
            this.lblPartModPrice.AutoSize = true;
            this.lblPartModPrice.Location = new System.Drawing.Point(79, 172);
            this.lblPartModPrice.Name = "lblPartModPrice";
            this.lblPartModPrice.Size = new System.Drawing.Size(63, 13);
            this.lblPartModPrice.TabIndex = 6;
            this.lblPartModPrice.Text = "Price / Cost";
            // 
            // lblPartModMax
            // 
            this.lblPartModMax.AutoSize = true;
            this.lblPartModMax.Location = new System.Drawing.Point(112, 207);
            this.lblPartModMax.Name = "lblPartModMax";
            this.lblPartModMax.Size = new System.Drawing.Size(27, 13);
            this.lblPartModMax.TabIndex = 7;
            this.lblPartModMax.Text = "Max";
            // 
            // lblPartModMin
            // 
            this.lblPartModMin.AutoSize = true;
            this.lblPartModMin.Location = new System.Drawing.Point(289, 207);
            this.lblPartModMin.Name = "lblPartModMin";
            this.lblPartModMin.Size = new System.Drawing.Size(24, 13);
            this.lblPartModMin.TabIndex = 8;
            this.lblPartModMin.Text = "Min";
            // 
            // lblPartModMachId
            // 
            this.lblPartModMachId.AutoSize = true;
            this.lblPartModMachId.Location = new System.Drawing.Point(80, 241);
            this.lblPartModMachId.Name = "lblPartModMachId";
            this.lblPartModMachId.Size = new System.Drawing.Size(62, 13);
            this.lblPartModMachId.TabIndex = 9;
            this.lblPartModMachId.Text = "Machine ID";
            // 
            // btnPartModSave
            // 
            this.btnPartModSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPartModSave.Location = new System.Drawing.Point(304, 285);
            this.btnPartModSave.Name = "btnPartModSave";
            this.btnPartModSave.Size = new System.Drawing.Size(65, 39);
            this.btnPartModSave.TabIndex = 10;
            this.btnPartModSave.Text = "Save";
            this.btnPartModSave.UseVisualStyleBackColor = true;
            this.btnPartModSave.Click += new System.EventHandler(this.btnPartModSave_Click);
            // 
            // txtBoxModPartId
            // 
            this.txtBoxModPartId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartId.Location = new System.Drawing.Point(164, 68);
            this.txtBoxModPartId.Name = "txtBoxModPartId";
            this.txtBoxModPartId.Size = new System.Drawing.Size(141, 20);
            this.txtBoxModPartId.TabIndex = 12;
            // 
            // txtBoxModPartName
            // 
            this.txtBoxModPartName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartName.Location = new System.Drawing.Point(164, 100);
            this.txtBoxModPartName.Name = "txtBoxModPartName";
            this.txtBoxModPartName.Size = new System.Drawing.Size(141, 20);
            this.txtBoxModPartName.TabIndex = 13;
            // 
            // txtBoxModPartInvent
            // 
            this.txtBoxModPartInvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartInvent.Location = new System.Drawing.Point(164, 134);
            this.txtBoxModPartInvent.Name = "txtBoxModPartInvent";
            this.txtBoxModPartInvent.Size = new System.Drawing.Size(141, 20);
            this.txtBoxModPartInvent.TabIndex = 14;
            // 
            // txtBoxModPartPrice
            // 
            this.txtBoxModPartPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartPrice.Location = new System.Drawing.Point(164, 170);
            this.txtBoxModPartPrice.Name = "txtBoxModPartPrice";
            this.txtBoxModPartPrice.Size = new System.Drawing.Size(141, 20);
            this.txtBoxModPartPrice.TabIndex = 15;
            // 
            // txtBoxModPartMachId
            // 
            this.txtBoxModPartMachId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartMachId.Location = new System.Drawing.Point(164, 241);
            this.txtBoxModPartMachId.Name = "txtBoxModPartMachId";
            this.txtBoxModPartMachId.Size = new System.Drawing.Size(141, 20);
            this.txtBoxModPartMachId.TabIndex = 16;
            // 
            // txtBoxModPartMax
            // 
            this.txtBoxModPartMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartMax.Location = new System.Drawing.Point(164, 205);
            this.txtBoxModPartMax.Name = "txtBoxModPartMax";
            this.txtBoxModPartMax.Size = new System.Drawing.Size(91, 20);
            this.txtBoxModPartMax.TabIndex = 17;
            // 
            // txtBoxModPartMin
            // 
            this.txtBoxModPartMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModPartMin.Location = new System.Drawing.Point(340, 205);
            this.txtBoxModPartMin.Name = "txtBoxModPartMin";
            this.txtBoxModPartMin.Size = new System.Drawing.Size(91, 20);
            this.txtBoxModPartMin.TabIndex = 18;
            // 
            // btnPartModCancel
            // 
            this.btnPartModCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPartModCancel.Location = new System.Drawing.Point(375, 285);
            this.btnPartModCancel.Name = "btnPartModCancel";
            this.btnPartModCancel.Size = new System.Drawing.Size(65, 39);
            this.btnPartModCancel.TabIndex = 19;
            this.btnPartModCancel.Text = "Cancel";
            this.btnPartModCancel.UseVisualStyleBackColor = true;
            this.btnPartModCancel.Click += new System.EventHandler(this.btnPartModCancel_Click);
            // 
            // errProvModPartId
            // 
            this.errProvModPartId.ContainerControl = this;
            // 
            // errProvModPartName
            // 
            this.errProvModPartName.ContainerControl = this;
            // 
            // errProvModPartInvent
            // 
            this.errProvModPartInvent.ContainerControl = this;
            // 
            // errProvModPartPrice
            // 
            this.errProvModPartPrice.ContainerControl = this;
            // 
            // errProvModPartMax
            // 
            this.errProvModPartMax.ContainerControl = this;
            // 
            // errProvModPartMin
            // 
            this.errProvModPartMin.ContainerControl = this;
            // 
            // errProvModPartMachId
            // 
            this.errProvModPartMachId.ContainerControl = this;
            // 
            // partModifyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 357);
            this.Controls.Add(this.btnPartModCancel);
            this.Controls.Add(this.txtBoxModPartMin);
            this.Controls.Add(this.txtBoxModPartMax);
            this.Controls.Add(this.txtBoxModPartMachId);
            this.Controls.Add(this.txtBoxModPartPrice);
            this.Controls.Add(this.txtBoxModPartInvent);
            this.Controls.Add(this.txtBoxModPartName);
            this.Controls.Add(this.txtBoxModPartId);
            this.Controls.Add(this.btnPartModSave);
            this.Controls.Add(this.lblPartModMachId);
            this.Controls.Add(this.lblPartModMin);
            this.Controls.Add(this.lblPartModMax);
            this.Controls.Add(this.lblPartModPrice);
            this.Controls.Add(this.lblPartModInvent);
            this.Controls.Add(this.lblPartModName);
            this.Controls.Add(this.lblPartModId);
            this.Controls.Add(this.rdoBtnOutSModify);
            this.Controls.Add(this.rdoBtnInHModify);
            this.Controls.Add(this.lblModifyPartTitle);
            this.Name = "partModifyForm";
            this.Text = "Part";
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartInvent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModPartMachId)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblModifyPartTitle;
        private System.Windows.Forms.RadioButton rdoBtnInHModify;
        private System.Windows.Forms.RadioButton rdoBtnOutSModify;
        private System.Windows.Forms.Label lblPartModId;
        private System.Windows.Forms.Label lblPartModName;
        private System.Windows.Forms.Label lblPartModInvent;
        private System.Windows.Forms.Label lblPartModPrice;
        private System.Windows.Forms.Label lblPartModMax;
        private System.Windows.Forms.Label lblPartModMin;
        private System.Windows.Forms.Label lblPartModMachId;
        private System.Windows.Forms.Button btnPartModSave;
        private System.Windows.Forms.Button btnPartModCancel;
        public System.Windows.Forms.TextBox txtBoxModPartId;
        public System.Windows.Forms.TextBox txtBoxModPartName;
        public System.Windows.Forms.TextBox txtBoxModPartInvent;
        public System.Windows.Forms.TextBox txtBoxModPartPrice;
        public System.Windows.Forms.TextBox txtBoxModPartMachId;
        public System.Windows.Forms.TextBox txtBoxModPartMax;
        public System.Windows.Forms.TextBox txtBoxModPartMin;
        private System.Windows.Forms.ErrorProvider errProvModPartId;
        private System.Windows.Forms.ErrorProvider errProvModPartName;
        private System.Windows.Forms.ErrorProvider errProvModPartInvent;
        private System.Windows.Forms.ErrorProvider errProvModPartPrice;
        private System.Windows.Forms.ErrorProvider errProvModPartMax;
        private System.Windows.Forms.ErrorProvider errProvModPartMin;
        private System.Windows.Forms.ErrorProvider errProvModPartMachId;
    }
}