﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareOneProject
{
    
    //FIX Modify Part and Product empty row null exception error
    //Create a way to add accessory part to product and have it saved throughout the project

    public class Inventory
    {       
        public void addPart(partParameters partP, mainForm currentMainForm) //DO THIS ONE FIRST
        {
            currentMainForm.dataGridView1.Rows.Add(partP.partId, partP.PartName, partP.partInvent, partP.partPrice, partP.partMax, partP.partMin, partP.partMachId);          
        }





        public void updatePart(partModifyForm modPart, partParameters partP)
        {          
            modPart.txtBoxModPartId.Text = partP.partId.ToString();
            modPart.txtBoxModPartName.Text = partP.PartName?.ToString(); 
            modPart.txtBoxModPartInvent.Text = partP.partInvent.ToString();
            modPart.txtBoxModPartPrice.Text = partP.partPrice.ToString();
            modPart.txtBoxModPartMax.Text = partP.partMax.ToString();
            modPart.txtBoxModPartMin.Text = partP.partMin.ToString();
            modPart.txtBoxModPartMachId.Text = partP.partMachId?.ToString(); 
        }





        public void deletePart(mainForm currentMainForm)
        {
            DataGridViewRow currentRow = currentMainForm.dataGridView1.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }
                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot Delete an empty row");
                }
                else
                {
                    DialogResult dialogResultDeletePart = MessageBox.Show("Are you sure you want to delete this part?", "", MessageBoxButtons.YesNo);

                    if (dialogResultDeletePart == DialogResult.Yes)
                    {                     
                        int rowIndex = currentMainForm.dataGridView1.CurrentCell.RowIndex;
                        currentMainForm.dataGridView1.Rows.RemoveAt(rowIndex);

                    }
                    else if (dialogResultDeletePart == DialogResult.No)
                    {
                        //Clicking no will just close the box without deleting
                    }
                }
            }
        }





        public void addProduct(Product addP, mainForm currentMainForm)
        {
            currentMainForm.dataGridView2.Rows.Add(addP.ProductID, addP.Name, addP.InStock, addP.Price, addP.Max, addP.Min);           
        }





        public void removeProduct(mainForm currentMainForm)
        {
            DataGridViewRow currentRow = currentMainForm.dataGridView2.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }

                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot delete an empty row");
                }
                else
                {
                    DialogResult dialogResultDeleteProduct = MessageBox.Show("Are you sure you want to delete this product?", "", MessageBoxButtons.YesNo);
                    if (dialogResultDeleteProduct == DialogResult.Yes)
                    {
                        string productName = currentRow.Cells[1].Value.ToString();
                        string xmlFileName = productName + ".xml";
                        string xmlFilePath = Path.Combine(Environment.CurrentDirectory, xmlFileName);

                        if (File.Exists(xmlFilePath))
                        {
                            try
                            {
                                File.Delete(xmlFilePath);
                            }
                            catch (Exception ex)
                            {
                                // You may add additional error handling or logging here if needed
                            }
                        }

                        int rowIndex = currentMainForm.dataGridView2.CurrentCell.RowIndex;
                        currentMainForm.dataGridView2.Rows.RemoveAt(rowIndex);
                    }
                    else if (dialogResultDeleteProduct == DialogResult.No)
                    {
                        // Clicking no will just close the box without deleting
                    }
                }
            }
        }





        public void lookupProduct(mainForm currentMainForm)
        {
            string searchGrid2 = currentMainForm.TxtBoxProdSearch.Text.ToLower();

            foreach (DataGridViewRow row in currentMainForm.dataGridView2.Rows) // Check every row in DataGridView1
            {
                if (!row.IsNewRow) //This if statement prevents the "Uncommitted new row cannot be deleted." error
                {
                    row.Visible = false; // Reset row visibility

                    foreach (DataGridViewCell cell in row.Cells) //Filter through each cell in the row that is being checked
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchGrid2)) // Compare the cell data with the user input from text box
                        {
                            row.Visible = true; //The data that matched user input was found, so make the row visible
                            break;
                        }
                    }
                }
            }
        }





        public void updateProduct(productModForm modProd, partParameters partP)
        {
            modProd.txtBoxModProdId.Text = partP.partId.ToString();
            modProd.txtBoxModProdName.Text = partP.PartName?.ToString();
            modProd.txtBoxModProdInvent.Text = partP.partInvent.ToString();
            modProd.txtBoxModProdPrice.Text = partP.partPrice.ToString();
            modProd.txtBoxModProdMax.Text = partP.partMax.ToString();
            modProd.txtBoxModProdMin.Text = partP.partMin.ToString();          
        }





        public void lookupPart(mainForm currentMainForm)
        {
            string searchGrid1 = currentMainForm.TxtBoxPartSearch.Text.ToLower();

            foreach (DataGridViewRow row in currentMainForm.dataGridView1.Rows) // Check every row in DataGridView1
            {
                if (!row.IsNewRow) //This if statement prevents the "Uncommitted new row cannot be deleted." error
                {
                    row.Visible = false; // Reset row visibility

                    foreach (DataGridViewCell cell in row.Cells) //Filter through each cell in the row that is being checked
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchGrid1)) // Compare the cell data with the user input from text box
                        {
                            row.Visible = true; //The data that matched user input was found, so make the row visible
                            break;
                        }
                    }
                }
            }
        }
        
    }
}
