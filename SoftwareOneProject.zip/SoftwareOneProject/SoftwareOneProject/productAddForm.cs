﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using static SoftwareOneProject.mainForm;

namespace SoftwareOneProject
{
    public partial class prodAddForm : Form
    {
        private mainForm mform;
        Product addProd = new Product();     
        public prodAddForm(mainForm mf)
        {
            InitializeComponent();
            this.mform = mf;           
        }       

        private void btnAddProdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddProdSave_Click(object sender, EventArgs e)
        {                      

            int prodIDResult;
            int prodInventResult;
            int prodMaxResult;
            int prodMinResult;          

            string namePatternProd = "^[a-zA-Z]+(\\s[a-zA-Z]+)?$";
            string pricePattern = "[0-9]+\\.?[0-9,]*";

            bool isNameValid = Regex.IsMatch(txtBoxAddProdName.Text, namePatternProd);
            bool isPriceValid = Regex.IsMatch(txtBoxAddProdPrice.Text, pricePattern);

            if (string.IsNullOrEmpty(txtBoxAddProdId.Text)) //Validation for add product ID
            {
                errProvAddProdID.SetError(txtBoxAddProdId, "Product ID is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddProdId.Text, out prodIDResult))
            {
                errProvAddProdID.SetError(txtBoxAddProdId, "Product ID must be a whole number");
                return;
            }
            else
            {
                errProvAddProdID.SetError(txtBoxAddProdId, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddProdName.Text)) //Validation for add product Name
            {
                errProvAddProdName.SetError(txtBoxAddProdName, "Product Name is required");
                return;
            }
            else if (!isNameValid)
            {
                errProvAddProdName.SetError(txtBoxAddProdName, "Product Name must only be letters");
                return;
            }
            else
            {
                errProvAddProdName.SetError(txtBoxAddProdName, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddProdInvent.Text)) //Validation for add product Inventory
            {
                errProvAddProdInvent.SetError(txtBoxAddProdInvent, "Product Inventory is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddProdInvent.Text, out prodInventResult))
            {
                errProvAddProdInvent.SetError(txtBoxAddProdInvent, "Inventory must be a whole number");
                return;
            }
            else
            {
                errProvAddProdInvent.SetError(txtBoxAddProdInvent, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddProdPrice.Text)) //Validation for add product Price
            {
                errProvAddProdPrice.SetError(txtBoxAddProdPrice, "Product Price is required");
                return;
            }
            else if (!isPriceValid)
            {
                errProvAddProdPrice.SetError(txtBoxAddProdPrice, "Price amount must be a decimal or use a comma");
                return;
            }
            else
            {
                errProvAddProdPrice.SetError(txtBoxAddProdPrice, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddProdMax.Text)) //Validation for add product Max
            {
                errProvAddProdMax.SetError(txtBoxAddProdMax, "Product Max is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddProdMax.Text, out prodMaxResult))
            {
                errProvAddProdMax.SetError(txtBoxAddProdMax, "Product Max must be a whole number");
                return;
            }
            else if (prodInventResult > prodMaxResult)
            {
                errProvAddProdInvent.SetError(txtBoxAddProdInvent, "Product Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvAddProdMax.SetError(txtBoxAddProdMax, string.Empty);
            }

            if (string.IsNullOrEmpty(txtBoxAddProdMin.Text)) //Validation for add product Min
            {
                errProvAddProdMin.SetError(txtBoxAddProdMin, "Product Min is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddProdMin.Text, out prodMinResult))
            {
                errProvAddProdMin.SetError(txtBoxAddProdMin, "Product Min must be a whole number");
                return;
            }
            else if (prodMinResult >= prodMaxResult)
            {
                errProvAddProdMin.SetError(txtBoxAddProdMin, "Product Min must be lower than part Max"); //Validate that Min is lower than Max
                return;
            }
            else if (prodInventResult < prodMinResult)
            {
                errProvAddProdInvent.SetError(txtBoxAddProdInvent, "Product Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvAddProdMin.SetError(txtBoxAddProdMin, string.Empty);
            }

            
            addProd.ProductID = int.Parse(txtBoxAddProdId.Text);
            addProd.Name = txtBoxAddProdName.Text;
            addProd.Price = decimal.Parse(txtBoxAddProdPrice.Text);
            addProd.InStock = int.Parse(txtBoxAddProdInvent.Text);
            addProd.Max = int.Parse(txtBoxAddProdMax.Text);
            addProd.Min = int.Parse(txtBoxAddProdMin.Text);                

            Inventory inventory = new Inventory();
            inventory.addProduct(addProd, mform);

            addProd.SaveDataGridViewState(txtBoxAddProdName.Text, this);

            this.Close();
        }

        private void btnAddProdAdd_Click(object sender, EventArgs e)
        {             
            addProd.addAssociatedPart(this); //KEEP THIS !!!!           
        }

        private void btnAddProdDelete_Click(object sender, EventArgs e)
        {            
            addProd.removeAssociatedPart(this);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            addProd.lookupAssociatedPart(this);
        }             
        private void prodAddForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
        private void prodAddForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void prodAddForm_Load(object sender, EventArgs e)
        {

        }
    }
}
