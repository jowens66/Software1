﻿namespace SoftwareOneProject
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ClmPartId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmInventory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmMax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmMin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmMachIdPart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.TxtBoxPartSearch = new System.Windows.Forms.TextBox();
            this.TxtBoxProdSearch = new System.Windows.Forms.TextBox();
            this.LblParts = new System.Windows.Forms.Label();
            this.LblProd = new System.Windows.Forms.Label();
            this.BtnAddPart = new System.Windows.Forms.Button();
            this.BtnModPart = new System.Windows.Forms.Button();
            this.BtnDelPart = new System.Windows.Forms.Button();
            this.BtnAddProd = new System.Windows.Forms.Button();
            this.BtnModProd = new System.Windows.Forms.Button();
            this.BtnDelProd = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.lblSrchPart = new System.Windows.Forms.Label();
            this.lblSrchProd = new System.Windows.Forms.Label();
            this.ClmProductId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmInventory2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmPrice2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmMax2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmMin2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.machId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(229, 17);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Inventory Management System";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmPartId,
            this.ClmName,
            this.ClmInventory,
            this.ClmPrice,
            this.ClmMax,
            this.ClmMin,
            this.clmMachIdPart});
            this.dataGridView1.Location = new System.Drawing.Point(2, 107);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(676, 141);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ClmPartId
            // 
            this.ClmPartId.HeaderText = "Part ID";
            this.ClmPartId.Name = "ClmPartId";
            this.ClmPartId.ReadOnly = true;
            // 
            // ClmName
            // 
            this.ClmName.HeaderText = "Name";
            this.ClmName.Name = "ClmName";
            this.ClmName.ReadOnly = true;
            // 
            // ClmInventory
            // 
            this.ClmInventory.HeaderText = "Inventory";
            this.ClmInventory.Name = "ClmInventory";
            this.ClmInventory.ReadOnly = true;
            // 
            // ClmPrice
            // 
            this.ClmPrice.HeaderText = "Price";
            this.ClmPrice.Name = "ClmPrice";
            this.ClmPrice.ReadOnly = true;
            // 
            // ClmMax
            // 
            this.ClmMax.HeaderText = "Max";
            this.ClmMax.Name = "ClmMax";
            this.ClmMax.ReadOnly = true;
            // 
            // ClmMin
            // 
            this.ClmMin.HeaderText = "Min";
            this.ClmMin.Name = "ClmMin";
            this.ClmMin.ReadOnly = true;
            // 
            // clmMachIdPart
            // 
            this.clmMachIdPart.HeaderText = "Machine ID";
            this.clmMachIdPart.Name = "clmMachIdPart";
            this.clmMachIdPart.ReadOnly = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmProductId,
            this.name,
            this.ClmInventory2,
            this.ClmPrice2,
            this.ClmMax2,
            this.ClmMin2,
            this.machId});
            this.dataGridView2.Location = new System.Drawing.Point(684, 107);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(606, 141);
            this.dataGridView2.TabIndex = 2;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // TxtBoxPartSearch
            // 
            this.TxtBoxPartSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtBoxPartSearch.Location = new System.Drawing.Point(342, 78);
            this.TxtBoxPartSearch.Name = "TxtBoxPartSearch";
            this.TxtBoxPartSearch.Size = new System.Drawing.Size(208, 20);
            this.TxtBoxPartSearch.TabIndex = 3;
            this.TxtBoxPartSearch.Tag = "";
            this.TxtBoxPartSearch.TextChanged += new System.EventHandler(this.TxtBoxPartSearch_TextChanged);
            // 
            // TxtBoxProdSearch
            // 
            this.TxtBoxProdSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtBoxProdSearch.Location = new System.Drawing.Point(1017, 81);
            this.TxtBoxProdSearch.Name = "TxtBoxProdSearch";
            this.TxtBoxProdSearch.Size = new System.Drawing.Size(208, 20);
            this.TxtBoxProdSearch.TabIndex = 5;
            this.TxtBoxProdSearch.TextChanged += new System.EventHandler(this.TxtBoxProdSearch_TextChanged);
            // 
            // LblParts
            // 
            this.LblParts.AutoSize = true;
            this.LblParts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblParts.Location = new System.Drawing.Point(2, 88);
            this.LblParts.Name = "LblParts";
            this.LblParts.Size = new System.Drawing.Size(43, 16);
            this.LblParts.TabIndex = 7;
            this.LblParts.Text = "Parts";
            // 
            // LblProd
            // 
            this.LblProd.AutoSize = true;
            this.LblProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblProd.Location = new System.Drawing.Point(681, 88);
            this.LblProd.Name = "LblProd";
            this.LblProd.Size = new System.Drawing.Size(68, 16);
            this.LblProd.TabIndex = 8;
            this.LblProd.Text = "Products";
            // 
            // BtnAddPart
            // 
            this.BtnAddPart.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnAddPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAddPart.Location = new System.Drawing.Point(441, 254);
            this.BtnAddPart.Name = "BtnAddPart";
            this.BtnAddPart.Size = new System.Drawing.Size(75, 36);
            this.BtnAddPart.TabIndex = 9;
            this.BtnAddPart.Text = "Add";
            this.BtnAddPart.UseVisualStyleBackColor = false;
            this.BtnAddPart.Click += new System.EventHandler(this.BtnAddPart_Click);
            // 
            // BtnModPart
            // 
            this.BtnModPart.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnModPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnModPart.Location = new System.Drawing.Point(522, 254);
            this.BtnModPart.Name = "BtnModPart";
            this.BtnModPart.Size = new System.Drawing.Size(75, 36);
            this.BtnModPart.TabIndex = 10;
            this.BtnModPart.Text = "Modify";
            this.BtnModPart.UseVisualStyleBackColor = false;
            this.BtnModPart.Click += new System.EventHandler(this.BtnModPart_Click);
            // 
            // BtnDelPart
            // 
            this.BtnDelPart.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnDelPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelPart.Location = new System.Drawing.Point(603, 254);
            this.BtnDelPart.Name = "BtnDelPart";
            this.BtnDelPart.Size = new System.Drawing.Size(75, 36);
            this.BtnDelPart.TabIndex = 11;
            this.BtnDelPart.Text = "Delete";
            this.BtnDelPart.UseVisualStyleBackColor = false;
            this.BtnDelPart.Click += new System.EventHandler(this.BtnDelPart_Click);
            // 
            // BtnAddProd
            // 
            this.BtnAddProd.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnAddProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAddProd.Location = new System.Drawing.Point(1049, 254);
            this.BtnAddProd.Name = "BtnAddProd";
            this.BtnAddProd.Size = new System.Drawing.Size(75, 36);
            this.BtnAddProd.TabIndex = 12;
            this.BtnAddProd.Text = "Add";
            this.BtnAddProd.UseVisualStyleBackColor = false;
            this.BtnAddProd.Click += new System.EventHandler(this.BtnAddProd_Click);
            // 
            // BtnModProd
            // 
            this.BtnModProd.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnModProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnModProd.Location = new System.Drawing.Point(1130, 254);
            this.BtnModProd.Name = "BtnModProd";
            this.BtnModProd.Size = new System.Drawing.Size(75, 36);
            this.BtnModProd.TabIndex = 13;
            this.BtnModProd.Text = "Modify";
            this.BtnModProd.UseVisualStyleBackColor = false;
            this.BtnModProd.Click += new System.EventHandler(this.BtnModProd_Click);
            // 
            // BtnDelProd
            // 
            this.BtnDelProd.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnDelProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelProd.Location = new System.Drawing.Point(1215, 254);
            this.BtnDelProd.Name = "BtnDelProd";
            this.BtnDelProd.Size = new System.Drawing.Size(75, 36);
            this.BtnDelProd.TabIndex = 14;
            this.BtnDelProd.Text = "Delete";
            this.BtnDelProd.UseVisualStyleBackColor = false;
            this.BtnDelProd.Click += new System.EventHandler(this.BtnDelProd_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.Location = new System.Drawing.Point(1215, 340);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(75, 36);
            this.BtnExit.TabIndex = 15;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // lblSrchPart
            // 
            this.lblSrchPart.AutoSize = true;
            this.lblSrchPart.Location = new System.Drawing.Point(295, 80);
            this.lblSrchPart.Name = "lblSrchPart";
            this.lblSrchPart.Size = new System.Drawing.Size(41, 13);
            this.lblSrchPart.TabIndex = 16;
            this.lblSrchPart.Text = "Search";
            // 
            // lblSrchProd
            // 
            this.lblSrchProd.AutoSize = true;
            this.lblSrchProd.Location = new System.Drawing.Point(970, 83);
            this.lblSrchProd.Name = "lblSrchProd";
            this.lblSrchProd.Size = new System.Drawing.Size(41, 13);
            this.lblSrchProd.TabIndex = 17;
            this.lblSrchProd.Text = "Search";
            // 
            // ClmProductId
            // 
            this.ClmProductId.HeaderText = "Product ID";
            this.ClmProductId.Name = "ClmProductId";
            this.ClmProductId.ReadOnly = true;
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // ClmInventory2
            // 
            this.ClmInventory2.HeaderText = "Inventory";
            this.ClmInventory2.Name = "ClmInventory2";
            this.ClmInventory2.ReadOnly = true;
            // 
            // ClmPrice2
            // 
            this.ClmPrice2.HeaderText = "Price";
            this.ClmPrice2.Name = "ClmPrice2";
            this.ClmPrice2.ReadOnly = true;
            // 
            // ClmMax2
            // 
            this.ClmMax2.HeaderText = "Max";
            this.ClmMax2.Name = "ClmMax2";
            this.ClmMax2.ReadOnly = true;
            // 
            // ClmMin2
            // 
            this.ClmMin2.HeaderText = "Min";
            this.ClmMin2.Name = "ClmMin2";
            this.ClmMin2.ReadOnly = true;
            // 
            // machId
            // 
            this.machId.HeaderText = "Machine ID";
            this.machId.Name = "machId";
            this.machId.ReadOnly = true;
            this.machId.Visible = false;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1298, 396);
            this.Controls.Add(this.lblSrchProd);
            this.Controls.Add(this.lblSrchPart);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnDelProd);
            this.Controls.Add(this.BtnModProd);
            this.Controls.Add(this.BtnAddProd);
            this.Controls.Add(this.BtnDelPart);
            this.Controls.Add(this.BtnModPart);
            this.Controls.Add(this.BtnAddPart);
            this.Controls.Add(this.LblProd);
            this.Controls.Add(this.LblParts);
            this.Controls.Add(this.TxtBoxProdSearch);
            this.Controls.Add(this.TxtBoxPartSearch);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblTitle);
            this.Name = "mainForm";
            this.Text = "Main Screen";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label LblParts;
        private System.Windows.Forms.Label LblProd;
        private System.Windows.Forms.Button BtnAddPart;
        private System.Windows.Forms.Button BtnModPart;
        private System.Windows.Forms.Button BtnDelPart;
        private System.Windows.Forms.Button BtnAddProd;
        private System.Windows.Forms.Button BtnModProd;
        private System.Windows.Forms.Button BtnDelProd;
        private System.Windows.Forms.Button BtnExit;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label lblSrchPart;
        public System.Windows.Forms.TextBox TxtBoxPartSearch;
        public System.Windows.Forms.TextBox TxtBoxProdSearch;
        private System.Windows.Forms.Label lblSrchProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmPartId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmMax;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmMin;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmMachIdPart;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmProductId;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmInventory2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmPrice2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmMax2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmMin2;
        private System.Windows.Forms.DataGridViewTextBoxColumn machId;
    }
}

