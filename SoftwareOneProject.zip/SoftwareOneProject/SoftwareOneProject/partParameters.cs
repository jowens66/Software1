﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareOneProject
{
    public class partParameters  //Data Transfer Objects
    {
        public int partId { get; set; }
        public string PartName { get; set; }
        public int partInvent { get; set; }
        public decimal partPrice { get; set; }
        public int partMax { get; set; }
        public int partMin { get; set; }
        public string partMachId { get; set; }
    }
}
