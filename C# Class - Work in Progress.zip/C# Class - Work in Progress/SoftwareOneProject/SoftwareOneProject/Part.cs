﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareOneProject
{
    public class Part
    {
        public int partId { get; set; }
        public string PartName { get; set; }
        public int partInvent { get; set; }
        public decimal partPrice { get; set; }
        public int partMax { get; set; }
        public int partMin { get; set; }
        public virtual int partMachId { get; set; } // Change the data type to int
                                                    
        public object MachorComp { get; set; } //Object that can be either the string or int

        public Part() { }

        public Part(int partID, string name, int inStock, decimal price, int min, int max)
        {
            partId = partID;
            PartName = name;
            partInvent = inStock;
            partPrice = price;
            partMin = min;
            partMax = max;
        }
    }
}
