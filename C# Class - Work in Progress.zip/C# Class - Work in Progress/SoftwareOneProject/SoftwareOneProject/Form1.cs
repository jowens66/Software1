﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;


namespace SoftwareOneProject
{
    public partial class mainForm : Form
    {
        Inventory inventory = new Inventory();

        private BindingList<Product> products;

        public mainForm()
        {
            InitializeComponent();
            
        }      

        private void Form1_Load(object sender, EventArgs e)
        {             
            //Populate rows for parts grid view               

            dataGridView1.Rows.Add(1, "Seat", 8, 4.55, 15, 2, 998877);
            dataGridView1.Rows.Add(2, "Wheel", 8, 4.55, 15, 2, 338811);
            dataGridView1.Rows.Add(3, "Handlebar", 8, 6.55, 15, 2, 003366);
            //dataGridView1.Rows.Add(3, "Spoke", 8, 10.55, 2, 15, 111111);
            //dataGridView1.Rows.Add(4, "Bell", 8, 2.99, 2, 15, 555555);
            //dataGridView1.Rows.Add(5, "Mirror", 8, 12.55, 2, 15, 777777);

            dataGridView2.Rows.Add(1, "Red Bicycle", 5, 30.99, 25, 4, 181375);
            dataGridView2.Rows.Add(2, "Yellow Bicycle", 19, 9.66, 22, 3, 224455);
            dataGridView2.Rows.Add(3, "Blue Bicycle", 4, 12.77, 24, 1, 999994);
            //dataGridView2.Rows.Add(3, "Green Bicycle", 6, 14.99, 1, 25, 647395);
            //dataGridView2.Rows.Add(4, "Purple Bicycle", 3, 24.99, 1, 25, 174493);
            //dataGridView2.Rows.Add(5, "White Bicycle", 16, 36.99, 1, 25, 1029546);           
        }
        


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnAddPart_Click(object sender, EventArgs e)
        {
            partAddForm addForm1 = new partAddForm(this);
            addForm1.Show(); //Show Add Part Form when clicked
        }





        private void BtnModPart_Click(object sender, EventArgs e)
        {
            partModifyForm modifyForm1 = new partModifyForm(this);
            Part partP = new Part();         
            DataGridViewRow currentRow = dataGridView1.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach(DataGridViewCell cell in currentRow.Cells)
                {
                    if(cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }

                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot modify an empty row");
                }
                else
                {                   
                    partP.partId = int.Parse(this.dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    partP.PartName = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    partP.partInvent = int.Parse(this.dataGridView1.CurrentRow.Cells[2].Value.ToString());
                    partP.partPrice = decimal.Parse(this.dataGridView1.CurrentRow.Cells[3].Value.ToString());
                    partP.partMax = int.Parse(this.dataGridView1.CurrentRow.Cells[4].Value.ToString());
                    partP.partMin = int.Parse(this.dataGridView1.CurrentRow.Cells[5].Value.ToString());
                    
                    partP.MachorComp = int.Parse(this.dataGridView1.CurrentRow.Cells[6].Value.ToString()); //doesnt work. Same issue as below trying to modify string from datagridview

                    //partP.partMachId = int.Parse(this.dataGridView1.CurrentRow.Cells[6].Value.ToString()); //Input string not in correct format error when you try to change company name to machine id from update
                                                                                                           
                    modifyForm1.Show(); //Show Modify Part Form when clicked
                }                   
            }                 
            inventory.updatePart(modifyForm1, partP);
          }


        private void BtnDelPart_Click(object sender, EventArgs e)
        {         
            inventory.deletePart(this); //Delete an entire row from the Part Table using method call                  
        }          

        private void BtnAddProd_Click(object sender, EventArgs e) //FIX THE DUPLICATE CLONE COLUMNS AND ROWS THAT ARE EMPTY
        {           

            prodAddForm productAddForm1 = new prodAddForm(this);
            BindingList<int> visibleColumns = new BindingList<int>();

            foreach(DataGridViewColumn col in dataGridView1.Columns)
            {
                if (col.Visible)
                {
                    productAddForm1.dataGridViewAddProdTop.Columns.Add((DataGridViewColumn)col.Clone()); //If thie column has data then it will clone it to the other datagridview
                    visibleColumns.Add(col.Index);
                }
            }

            int rowIndex = 0;

            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                productAddForm1.dataGridViewAddProdTop.Rows.Add();

                for(int i = 0; i < visibleColumns.Count; i++)
                {
                    productAddForm1.dataGridViewAddProdTop.Rows[rowIndex].Cells[i].Value = row.Cells[visibleColumns[i]].Value; //Check every cell and column and then iterate through to grab data
                }
                rowIndex++;
            }

            //// The following code checks to make sure that any blank columns that were cloned from the first datagridview on form1 are hidden
            for (int columnIndex = productAddForm1.dataGridViewAddProdTop.Columns.Count - 1; columnIndex >= 7; columnIndex--)
            {
                bool isColumnEmpty = true;

                foreach (DataGridViewRow row in productAddForm1.dataGridViewAddProdTop.Rows)
                {
                    if (row.Cells[columnIndex].Value != null && !string.IsNullOrEmpty(row.Cells[columnIndex].Value.ToString()))
                    {
                        isColumnEmpty = false;
                        break;
                    }
                }

                if (isColumnEmpty)
                {
                    productAddForm1.dataGridViewAddProdTop.Columns[columnIndex].Visible = false;
                }
            }
            //// All of the blank cloned columns from datagridview1 should be hidden on the add product top datagridview?                     

           

            productAddForm1.Show(); //Show Add Product form when clicked          
        }


        private void BtnModProd_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dataGridView2.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }

                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot modify an empty row");
                }
                else
                {
                    string productName = currentRow.Cells[1].Value.ToString(); // Get the product name from the selected row

                    string xmlFileName = productName + ".xml"; // Assuming the XML file name is the product name + ".xml"
                    string xmlFilePath = Path.Combine(Environment.CurrentDirectory, xmlFileName); // Assuming the XML file is in the current directory

                    productModForm productModForm1 = new productModForm(this);

                    if (File.Exists(xmlFilePath))
                    {
                        productModForm1.LoadXmlData(xmlFilePath); // Load the XML data into productModForm
                    }

                    BindingList<int> visibleColumns = new BindingList<int>();

                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        if (col.Visible)
                        {
                            // Add the existing columns from dataGridView1 to dataGridViewModProdTop
                            DataGridViewColumn clonedColumn = (DataGridViewColumn)col.Clone();
                            clonedColumn.HeaderText = col.HeaderText; // Set the cloned column's header text to match the existing column
                            productModForm1.dataGridViewModProdTop.Columns.Add(clonedColumn);

                            visibleColumns.Add(col.Index);
                        }
                    }

                    int rowIndex = 0;

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        productModForm1.dataGridViewModProdTop.Rows.Add();

                        for (int i = 0; i < visibleColumns.Count; i++)
                        {
                            productModForm1.dataGridViewModProdTop.Rows[rowIndex].Cells[i].Value = row.Cells[visibleColumns[i]].Value; // Copy the cell values from dataGridView1 to dataGridViewModProdTop
                        }

                        rowIndex++;
                    }

                    // Remove extra columns from dataGridViewModProdTop
                    for (int columnIndex = productModForm1.dataGridViewModProdTop.Columns.Count - 1; columnIndex >= visibleColumns.Count; columnIndex--)
                    {
                        productModForm1.dataGridViewModProdTop.Columns.RemoveAt(columnIndex);
                    }

                    Part partP = new Part();
                    partP.partId = int.Parse(currentRow.Cells[0].Value.ToString());
                    partP.PartName = currentRow.Cells[1].Value.ToString();
                    partP.partInvent = int.Parse(currentRow.Cells[2].Value.ToString());
                    partP.partPrice = decimal.Parse(currentRow.Cells[3].Value.ToString());
                    partP.partMax = int.Parse(currentRow.Cells[4].Value.ToString());
                    partP.partMin = int.Parse(currentRow.Cells[5].Value.ToString());

                    productModForm1.Show(); // Show productModForm
                    inventory.updateProduct(productModForm1, partP);
                }
            }
        }


        private void BtnDelProd_Click(object sender, EventArgs e)
        {
            inventory.removeProduct(this); //Call Method to delete product from datagridview2                    
        }       

        private void TxtBoxPartSearch_TextChanged(object sender, EventArgs e)
        {
            inventory.lookupPart(this); //Call Method for the search box on parts datagridview1
        }

        private void TxtBoxProdSearch_TextChanged(object sender, EventArgs e)
        {
            inventory.lookupProduct(this);
        }
    }
}
