﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareOneProject
{
    internal class InHouse : Part
    {
        public int MachineID { get; set; }

        public InHouse() { }

        public InHouse(int partID, string name, int inStock, decimal price, int min, int max, int machineID)
            : base(partID, name, inStock, price, min, max) // Call base constructor first
        {
            MachineID = machineID; // Set the MachineID property
        }
        public override int partMachId
        {
            get => MachineID;
            set => MachineID = value;
        }      
    }
}