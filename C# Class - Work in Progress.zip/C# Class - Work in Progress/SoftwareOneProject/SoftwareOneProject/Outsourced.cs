﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareOneProject
{
    internal class Outsourced : Part
    {
        public string CompanyName { get; set; }

        public Outsourced() { }

        public Outsourced(int partID, string name, int inStock, decimal price, int min, int max, string companyID)
            : base(partID, name, inStock, price, min, max) // Call base constructor first
        {
            CompanyName = companyID; // Set the CompanyName property
        }
        public override int partMachId
        {
            get => base.partMachId;
            set => base.partMachId = value;
        }
    }
}