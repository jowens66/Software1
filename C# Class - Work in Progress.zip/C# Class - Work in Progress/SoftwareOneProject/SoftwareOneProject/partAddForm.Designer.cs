﻿namespace SoftwareOneProject
{
    partial class partAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblAddPartFormTitle = new System.Windows.Forms.Label();
            this.rdoBtnInHAdd = new System.Windows.Forms.RadioButton();
            this.rdoBtnOutSAdd = new System.Windows.Forms.RadioButton();
            this.txtBoxAddPartId = new System.Windows.Forms.TextBox();
            this.txtBoxAddPartName = new System.Windows.Forms.TextBox();
            this.txtBoxAddPartInvent = new System.Windows.Forms.TextBox();
            this.txtBoxAddPartPrice = new System.Windows.Forms.TextBox();
            this.txtBoxAddPartMax = new System.Windows.Forms.TextBox();
            this.txtBoxAddPartMachId = new System.Windows.Forms.TextBox();
            this.txtBoxAddPartMin = new System.Windows.Forms.TextBox();
            this.btnSveAddPart = new System.Windows.Forms.Button();
            this.btnCancelAddPart = new System.Windows.Forms.Button();
            this.lblAddPartID = new System.Windows.Forms.Label();
            this.lblNameAddPart = new System.Windows.Forms.Label();
            this.lblInventAddPart = new System.Windows.Forms.Label();
            this.lblPriceAddPart = new System.Windows.Forms.Label();
            this.lblMaxAddPart = new System.Windows.Forms.Label();
            this.LblMinAddPart = new System.Windows.Forms.Label();
            this.lblMachIdAddPart = new System.Windows.Forms.Label();
            this.errProvAddPartId = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddPartName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddPartInvent = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddPartPrice = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddPartMax = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddPartMin = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddPartMachId = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartInvent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartMachId)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAddPartFormTitle
            // 
            this.lblAddPartFormTitle.AutoSize = true;
            this.lblAddPartFormTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddPartFormTitle.Location = new System.Drawing.Point(3, 9);
            this.lblAddPartFormTitle.Name = "lblAddPartFormTitle";
            this.lblAddPartFormTitle.Size = new System.Drawing.Size(67, 16);
            this.lblAddPartFormTitle.TabIndex = 0;
            this.lblAddPartFormTitle.Text = "Add Part";
            // 
            // rdoBtnInHAdd
            // 
            this.rdoBtnInHAdd.AutoSize = true;
            this.rdoBtnInHAdd.Checked = true;
            this.rdoBtnInHAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoBtnInHAdd.Location = new System.Drawing.Point(110, 9);
            this.rdoBtnInHAdd.Name = "rdoBtnInHAdd";
            this.rdoBtnInHAdd.Size = new System.Drawing.Size(76, 17);
            this.rdoBtnInHAdd.TabIndex = 1;
            this.rdoBtnInHAdd.TabStop = true;
            this.rdoBtnInHAdd.Text = "In-House";
            this.rdoBtnInHAdd.UseVisualStyleBackColor = true;
            this.rdoBtnInHAdd.CheckedChanged += new System.EventHandler(this.rdoBtnInHAdd_CheckedChanged);
            // 
            // rdoBtnOutSAdd
            // 
            this.rdoBtnOutSAdd.AutoSize = true;
            this.rdoBtnOutSAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoBtnOutSAdd.Location = new System.Drawing.Point(210, 9);
            this.rdoBtnOutSAdd.Name = "rdoBtnOutSAdd";
            this.rdoBtnOutSAdd.Size = new System.Drawing.Size(90, 17);
            this.rdoBtnOutSAdd.TabIndex = 2;
            this.rdoBtnOutSAdd.Text = "Outsourced";
            this.rdoBtnOutSAdd.UseVisualStyleBackColor = true;
            this.rdoBtnOutSAdd.CheckedChanged += new System.EventHandler(this.rdoBtnOutSAdd_CheckedChanged);
            // 
            // txtBoxAddPartId
            // 
            this.txtBoxAddPartId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartId.Location = new System.Drawing.Point(148, 55);
            this.txtBoxAddPartId.Name = "txtBoxAddPartId";
            this.txtBoxAddPartId.Size = new System.Drawing.Size(134, 20);
            this.txtBoxAddPartId.TabIndex = 3;
            // 
            // txtBoxAddPartName
            // 
            this.txtBoxAddPartName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartName.Location = new System.Drawing.Point(148, 95);
            this.txtBoxAddPartName.Name = "txtBoxAddPartName";
            this.txtBoxAddPartName.Size = new System.Drawing.Size(134, 20);
            this.txtBoxAddPartName.TabIndex = 4;
            // 
            // txtBoxAddPartInvent
            // 
            this.txtBoxAddPartInvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartInvent.Location = new System.Drawing.Point(148, 136);
            this.txtBoxAddPartInvent.Name = "txtBoxAddPartInvent";
            this.txtBoxAddPartInvent.Size = new System.Drawing.Size(134, 20);
            this.txtBoxAddPartInvent.TabIndex = 5;
            // 
            // txtBoxAddPartPrice
            // 
            this.txtBoxAddPartPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartPrice.Location = new System.Drawing.Point(148, 175);
            this.txtBoxAddPartPrice.Name = "txtBoxAddPartPrice";
            this.txtBoxAddPartPrice.Size = new System.Drawing.Size(134, 20);
            this.txtBoxAddPartPrice.TabIndex = 6;
            // 
            // txtBoxAddPartMax
            // 
            this.txtBoxAddPartMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartMax.Location = new System.Drawing.Point(148, 215);
            this.txtBoxAddPartMax.Name = "txtBoxAddPartMax";
            this.txtBoxAddPartMax.Size = new System.Drawing.Size(77, 20);
            this.txtBoxAddPartMax.TabIndex = 7;
            // 
            // txtBoxAddPartMachId
            // 
            this.txtBoxAddPartMachId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartMachId.Location = new System.Drawing.Point(148, 255);
            this.txtBoxAddPartMachId.Name = "txtBoxAddPartMachId";
            this.txtBoxAddPartMachId.Size = new System.Drawing.Size(134, 20);
            this.txtBoxAddPartMachId.TabIndex = 8;
            // 
            // txtBoxAddPartMin
            // 
            this.txtBoxAddPartMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddPartMin.Location = new System.Drawing.Point(286, 213);
            this.txtBoxAddPartMin.Name = "txtBoxAddPartMin";
            this.txtBoxAddPartMin.Size = new System.Drawing.Size(77, 20);
            this.txtBoxAddPartMin.TabIndex = 9;
            // 
            // btnSveAddPart
            // 
            this.btnSveAddPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSveAddPart.Location = new System.Drawing.Point(321, 295);
            this.btnSveAddPart.Name = "btnSveAddPart";
            this.btnSveAddPart.Size = new System.Drawing.Size(65, 36);
            this.btnSveAddPart.TabIndex = 10;
            this.btnSveAddPart.Text = "Save";
            this.btnSveAddPart.UseVisualStyleBackColor = true;
            this.btnSveAddPart.Click += new System.EventHandler(this.btnSveAddPart_Click);
            // 
            // btnCancelAddPart
            // 
            this.btnCancelAddPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelAddPart.Location = new System.Drawing.Point(392, 295);
            this.btnCancelAddPart.Name = "btnCancelAddPart";
            this.btnCancelAddPart.Size = new System.Drawing.Size(65, 36);
            this.btnCancelAddPart.TabIndex = 11;
            this.btnCancelAddPart.Text = "Cancel";
            this.btnCancelAddPart.UseVisualStyleBackColor = true;
            this.btnCancelAddPart.Click += new System.EventHandler(this.btnCancelAddPart_Click);
            // 
            // lblAddPartID
            // 
            this.lblAddPartID.AutoSize = true;
            this.lblAddPartID.Location = new System.Drawing.Point(107, 57);
            this.lblAddPartID.Name = "lblAddPartID";
            this.lblAddPartID.Size = new System.Drawing.Size(18, 13);
            this.lblAddPartID.TabIndex = 12;
            this.lblAddPartID.Text = "ID";
            // 
            // lblNameAddPart
            // 
            this.lblNameAddPart.AutoSize = true;
            this.lblNameAddPart.Location = new System.Drawing.Point(90, 97);
            this.lblNameAddPart.Name = "lblNameAddPart";
            this.lblNameAddPart.Size = new System.Drawing.Size(35, 13);
            this.lblNameAddPart.TabIndex = 13;
            this.lblNameAddPart.Text = "Name";
            // 
            // lblInventAddPart
            // 
            this.lblInventAddPart.AutoSize = true;
            this.lblInventAddPart.Location = new System.Drawing.Point(74, 138);
            this.lblInventAddPart.Name = "lblInventAddPart";
            this.lblInventAddPart.Size = new System.Drawing.Size(51, 13);
            this.lblInventAddPart.TabIndex = 14;
            this.lblInventAddPart.Text = "Inventory";
            // 
            // lblPriceAddPart
            // 
            this.lblPriceAddPart.AutoSize = true;
            this.lblPriceAddPart.Location = new System.Drawing.Point(62, 177);
            this.lblPriceAddPart.Name = "lblPriceAddPart";
            this.lblPriceAddPart.Size = new System.Drawing.Size(63, 13);
            this.lblPriceAddPart.TabIndex = 15;
            this.lblPriceAddPart.Text = "Price / Cost";
            // 
            // lblMaxAddPart
            // 
            this.lblMaxAddPart.AutoSize = true;
            this.lblMaxAddPart.Location = new System.Drawing.Point(90, 217);
            this.lblMaxAddPart.Name = "lblMaxAddPart";
            this.lblMaxAddPart.Size = new System.Drawing.Size(27, 13);
            this.lblMaxAddPart.TabIndex = 16;
            this.lblMaxAddPart.Text = "Max";
            // 
            // LblMinAddPart
            // 
            this.LblMinAddPart.AutoSize = true;
            this.LblMinAddPart.Location = new System.Drawing.Point(256, 217);
            this.LblMinAddPart.Name = "LblMinAddPart";
            this.LblMinAddPart.Size = new System.Drawing.Size(24, 13);
            this.LblMinAddPart.TabIndex = 17;
            this.LblMinAddPart.Text = "Min";
            // 
            // lblMachIdAddPart
            // 
            this.lblMachIdAddPart.AutoSize = true;
            this.lblMachIdAddPart.Location = new System.Drawing.Point(55, 257);
            this.lblMachIdAddPart.Name = "lblMachIdAddPart";
            this.lblMachIdAddPart.Size = new System.Drawing.Size(62, 13);
            this.lblMachIdAddPart.TabIndex = 18;
            this.lblMachIdAddPart.Text = "Machine ID";
            // 
            // errProvAddPartId
            // 
            this.errProvAddPartId.ContainerControl = this;
            // 
            // errProvAddPartName
            // 
            this.errProvAddPartName.ContainerControl = this;
            // 
            // errProvAddPartInvent
            // 
            this.errProvAddPartInvent.ContainerControl = this;
            // 
            // errProvAddPartPrice
            // 
            this.errProvAddPartPrice.ContainerControl = this;
            // 
            // errProvAddPartMax
            // 
            this.errProvAddPartMax.ContainerControl = this;
            // 
            // errProvAddPartMin
            // 
            this.errProvAddPartMin.ContainerControl = this;
            // 
            // errProvAddPartMachId
            // 
            this.errProvAddPartMachId.ContainerControl = this;
            // 
            // partAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 352);
            this.Controls.Add(this.lblMachIdAddPart);
            this.Controls.Add(this.LblMinAddPart);
            this.Controls.Add(this.lblMaxAddPart);
            this.Controls.Add(this.lblPriceAddPart);
            this.Controls.Add(this.lblInventAddPart);
            this.Controls.Add(this.lblNameAddPart);
            this.Controls.Add(this.lblAddPartID);
            this.Controls.Add(this.btnCancelAddPart);
            this.Controls.Add(this.btnSveAddPart);
            this.Controls.Add(this.txtBoxAddPartMin);
            this.Controls.Add(this.txtBoxAddPartMachId);
            this.Controls.Add(this.txtBoxAddPartMax);
            this.Controls.Add(this.txtBoxAddPartPrice);
            this.Controls.Add(this.txtBoxAddPartInvent);
            this.Controls.Add(this.txtBoxAddPartName);
            this.Controls.Add(this.txtBoxAddPartId);
            this.Controls.Add(this.rdoBtnOutSAdd);
            this.Controls.Add(this.rdoBtnInHAdd);
            this.Controls.Add(this.lblAddPartFormTitle);
            this.Name = "partAddForm";
            this.Text = "Part";
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartInvent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddPartMachId)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddPartFormTitle;
        private System.Windows.Forms.RadioButton rdoBtnInHAdd;
        private System.Windows.Forms.RadioButton rdoBtnOutSAdd;
        private System.Windows.Forms.Button btnSveAddPart;
        private System.Windows.Forms.Button btnCancelAddPart;
        private System.Windows.Forms.Label lblAddPartID;
        private System.Windows.Forms.Label lblNameAddPart;
        private System.Windows.Forms.Label lblInventAddPart;
        private System.Windows.Forms.Label lblPriceAddPart;
        private System.Windows.Forms.Label lblMaxAddPart;
        private System.Windows.Forms.Label LblMinAddPart;
        private System.Windows.Forms.Label lblMachIdAddPart;
        private System.Windows.Forms.ErrorProvider errProvAddPartId;
        private System.Windows.Forms.ErrorProvider errProvAddPartName;
        private System.Windows.Forms.ErrorProvider errProvAddPartInvent;
        private System.Windows.Forms.ErrorProvider errProvAddPartPrice;
        private System.Windows.Forms.ErrorProvider errProvAddPartMax;
        private System.Windows.Forms.ErrorProvider errProvAddPartMin;
        private System.Windows.Forms.ErrorProvider errProvAddPartMachId;
        public System.Windows.Forms.TextBox txtBoxAddPartId;
        public System.Windows.Forms.TextBox txtBoxAddPartName;
        public System.Windows.Forms.TextBox txtBoxAddPartInvent;
        public System.Windows.Forms.TextBox txtBoxAddPartPrice;
        public System.Windows.Forms.TextBox txtBoxAddPartMax;
        public System.Windows.Forms.TextBox txtBoxAddPartMachId;
        public System.Windows.Forms.TextBox txtBoxAddPartMin;
    }
}