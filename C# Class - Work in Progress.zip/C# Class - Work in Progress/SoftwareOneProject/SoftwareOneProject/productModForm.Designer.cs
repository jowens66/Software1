﻿namespace SoftwareOneProject
{
    partial class productModForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblModProdTitle = new System.Windows.Forms.Label();
            this.lblModProdId = new System.Windows.Forms.Label();
            this.lblModProdName = new System.Windows.Forms.Label();
            this.lblModProdInvent = new System.Windows.Forms.Label();
            this.lblModProdPrice = new System.Windows.Forms.Label();
            this.lblModProdMin = new System.Windows.Forms.Label();
            this.lblModProdMax = new System.Windows.Forms.Label();
            this.txtBoxModProdId = new System.Windows.Forms.TextBox();
            this.txtBoxModProdInvent = new System.Windows.Forms.TextBox();
            this.txtBoxModProdName = new System.Windows.Forms.TextBox();
            this.txtBoxModProdPrice = new System.Windows.Forms.TextBox();
            this.txtBoxModProdMax = new System.Windows.Forms.TextBox();
            this.txtBoxModProdMin = new System.Windows.Forms.TextBox();
            this.dataGridViewModProdTop = new System.Windows.Forms.DataGridView();
            this.prodModIdTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModNameTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModInventTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModPriceTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModMaxTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModMinTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModMachIdTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewModProdBottom = new System.Windows.Forms.DataGridView();
            this.lblProdModAllParts = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnModProdCancel = new System.Windows.Forms.Button();
            this.btnModProdSave = new System.Windows.Forms.Button();
            this.btnModProdDel = new System.Windows.Forms.Button();
            this.btnModProdAllPartAdd = new System.Windows.Forms.Button();
            this.txtBoxSearchModProd = new System.Windows.Forms.TextBox();
            this.errProvModProdId = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModProdName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModProdInvent = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModProdPrice = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModProdMax = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvModProdMin = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblSearchModProd = new System.Windows.Forms.Label();
            this.prodModIdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModNameBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModInventBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModPriceBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModMaxBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodModMinBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.machIdModBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewModProdTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewModProdBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdInvent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdMin)).BeginInit();
            this.SuspendLayout();
            // 
            // lblModProdTitle
            // 
            this.lblModProdTitle.AutoSize = true;
            this.lblModProdTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdTitle.Location = new System.Drawing.Point(12, 28);
            this.lblModProdTitle.Name = "lblModProdTitle";
            this.lblModProdTitle.Size = new System.Drawing.Size(110, 16);
            this.lblModProdTitle.TabIndex = 0;
            this.lblModProdTitle.Text = "Modify Product";
            // 
            // lblModProdId
            // 
            this.lblModProdId.AutoSize = true;
            this.lblModProdId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdId.Location = new System.Drawing.Point(13, 182);
            this.lblModProdId.Name = "lblModProdId";
            this.lblModProdId.Size = new System.Drawing.Size(20, 13);
            this.lblModProdId.TabIndex = 1;
            this.lblModProdId.Text = "ID";
            // 
            // lblModProdName
            // 
            this.lblModProdName.AutoSize = true;
            this.lblModProdName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdName.Location = new System.Drawing.Point(13, 222);
            this.lblModProdName.Name = "lblModProdName";
            this.lblModProdName.Size = new System.Drawing.Size(39, 13);
            this.lblModProdName.TabIndex = 2;
            this.lblModProdName.Text = "Name";
            // 
            // lblModProdInvent
            // 
            this.lblModProdInvent.AutoSize = true;
            this.lblModProdInvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdInvent.Location = new System.Drawing.Point(13, 264);
            this.lblModProdInvent.Name = "lblModProdInvent";
            this.lblModProdInvent.Size = new System.Drawing.Size(60, 13);
            this.lblModProdInvent.TabIndex = 3;
            this.lblModProdInvent.Text = "Inventory";
            // 
            // lblModProdPrice
            // 
            this.lblModProdPrice.AutoSize = true;
            this.lblModProdPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdPrice.Location = new System.Drawing.Point(13, 302);
            this.lblModProdPrice.Name = "lblModProdPrice";
            this.lblModProdPrice.Size = new System.Drawing.Size(36, 13);
            this.lblModProdPrice.TabIndex = 4;
            this.lblModProdPrice.Text = "Price";
            // 
            // lblModProdMin
            // 
            this.lblModProdMin.AutoSize = true;
            this.lblModProdMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdMin.Location = new System.Drawing.Point(218, 343);
            this.lblModProdMin.Name = "lblModProdMin";
            this.lblModProdMin.Size = new System.Drawing.Size(27, 13);
            this.lblModProdMin.TabIndex = 5;
            this.lblModProdMin.Text = "Min";
            // 
            // lblModProdMax
            // 
            this.lblModProdMax.AutoSize = true;
            this.lblModProdMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModProdMax.Location = new System.Drawing.Point(13, 343);
            this.lblModProdMax.Name = "lblModProdMax";
            this.lblModProdMax.Size = new System.Drawing.Size(30, 13);
            this.lblModProdMax.TabIndex = 6;
            this.lblModProdMax.Text = "Max";
            // 
            // txtBoxModProdId
            // 
            this.txtBoxModProdId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModProdId.Location = new System.Drawing.Point(79, 180);
            this.txtBoxModProdId.Name = "txtBoxModProdId";
            this.txtBoxModProdId.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModProdId.TabIndex = 7;
            // 
            // txtBoxModProdInvent
            // 
            this.txtBoxModProdInvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModProdInvent.Location = new System.Drawing.Point(79, 262);
            this.txtBoxModProdInvent.Name = "txtBoxModProdInvent";
            this.txtBoxModProdInvent.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModProdInvent.TabIndex = 8;
            // 
            // txtBoxModProdName
            // 
            this.txtBoxModProdName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModProdName.Location = new System.Drawing.Point(79, 220);
            this.txtBoxModProdName.Name = "txtBoxModProdName";
            this.txtBoxModProdName.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModProdName.TabIndex = 9;
            // 
            // txtBoxModProdPrice
            // 
            this.txtBoxModProdPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModProdPrice.Location = new System.Drawing.Point(79, 300);
            this.txtBoxModProdPrice.Name = "txtBoxModProdPrice";
            this.txtBoxModProdPrice.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModProdPrice.TabIndex = 10;
            // 
            // txtBoxModProdMax
            // 
            this.txtBoxModProdMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModProdMax.Location = new System.Drawing.Point(79, 341);
            this.txtBoxModProdMax.Name = "txtBoxModProdMax";
            this.txtBoxModProdMax.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModProdMax.TabIndex = 11;
            // 
            // txtBoxModProdMin
            // 
            this.txtBoxModProdMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxModProdMin.Location = new System.Drawing.Point(251, 341);
            this.txtBoxModProdMin.Name = "txtBoxModProdMin";
            this.txtBoxModProdMin.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModProdMin.TabIndex = 12;
            // 
            // dataGridViewModProdTop
            // 
            this.dataGridViewModProdTop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewModProdTop.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodModIdTop,
            this.prodModNameTop,
            this.prodModInventTop,
            this.prodModPriceTop,
            this.prodModMaxTop,
            this.prodModMinTop,
            this.prodModMachIdTop});
            this.dataGridViewModProdTop.Location = new System.Drawing.Point(453, 62);
            this.dataGridViewModProdTop.Name = "dataGridViewModProdTop";
            this.dataGridViewModProdTop.ReadOnly = true;
            this.dataGridViewModProdTop.RowHeadersVisible = false;
            this.dataGridViewModProdTop.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewModProdTop.Size = new System.Drawing.Size(360, 150);
            this.dataGridViewModProdTop.TabIndex = 13;
            // 
            // prodModIdTop
            // 
            this.prodModIdTop.HeaderText = "Id";
            this.prodModIdTop.Name = "prodModIdTop";
            this.prodModIdTop.ReadOnly = true;
            // 
            // prodModNameTop
            // 
            this.prodModNameTop.HeaderText = "Name";
            this.prodModNameTop.Name = "prodModNameTop";
            this.prodModNameTop.ReadOnly = true;
            // 
            // prodModInventTop
            // 
            this.prodModInventTop.HeaderText = "Inventory";
            this.prodModInventTop.Name = "prodModInventTop";
            this.prodModInventTop.ReadOnly = true;
            // 
            // prodModPriceTop
            // 
            this.prodModPriceTop.HeaderText = "Price";
            this.prodModPriceTop.Name = "prodModPriceTop";
            this.prodModPriceTop.ReadOnly = true;
            // 
            // prodModMaxTop
            // 
            this.prodModMaxTop.HeaderText = "Max";
            this.prodModMaxTop.Name = "prodModMaxTop";
            this.prodModMaxTop.ReadOnly = true;
            // 
            // prodModMinTop
            // 
            this.prodModMinTop.HeaderText = "Min";
            this.prodModMinTop.Name = "prodModMinTop";
            this.prodModMinTop.ReadOnly = true;
            // 
            // prodModMachIdTop
            // 
            this.prodModMachIdTop.HeaderText = "Machine Id/Company Name";
            this.prodModMachIdTop.Name = "prodModMachIdTop";
            this.prodModMachIdTop.ReadOnly = true;
            // 
            // dataGridViewModProdBottom
            // 
            this.dataGridViewModProdBottom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewModProdBottom.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodModIdBottom,
            this.prodModNameBottom,
            this.prodModInventBottom,
            this.prodModPriceBottom,
            this.prodModMaxBottom,
            this.prodModMinBottom,
            this.machIdModBottom});
            this.dataGridViewModProdBottom.Location = new System.Drawing.Point(453, 282);
            this.dataGridViewModProdBottom.Name = "dataGridViewModProdBottom";
            this.dataGridViewModProdBottom.ReadOnly = true;
            this.dataGridViewModProdBottom.RowHeadersVisible = false;
            this.dataGridViewModProdBottom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewModProdBottom.Size = new System.Drawing.Size(360, 150);
            this.dataGridViewModProdBottom.TabIndex = 14;
            // 
            // lblProdModAllParts
            // 
            this.lblProdModAllParts.AutoSize = true;
            this.lblProdModAllParts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdModAllParts.Location = new System.Drawing.Point(450, 46);
            this.lblProdModAllParts.Name = "lblProdModAllParts";
            this.lblProdModAllParts.Size = new System.Drawing.Size(54, 13);
            this.lblProdModAllParts.TabIndex = 15;
            this.lblProdModAllParts.Text = "All Parts";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(450, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Parts Associated with this Product";
            // 
            // btnModProdCancel
            // 
            this.btnModProdCancel.Location = new System.Drawing.Point(723, 487);
            this.btnModProdCancel.Name = "btnModProdCancel";
            this.btnModProdCancel.Size = new System.Drawing.Size(75, 35);
            this.btnModProdCancel.TabIndex = 17;
            this.btnModProdCancel.Text = "Cancel";
            this.btnModProdCancel.UseVisualStyleBackColor = true;
            this.btnModProdCancel.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnModProdSave
            // 
            this.btnModProdSave.Location = new System.Drawing.Point(642, 487);
            this.btnModProdSave.Name = "btnModProdSave";
            this.btnModProdSave.Size = new System.Drawing.Size(75, 35);
            this.btnModProdSave.TabIndex = 18;
            this.btnModProdSave.Text = "Save";
            this.btnModProdSave.UseVisualStyleBackColor = true;
            this.btnModProdSave.Click += new System.EventHandler(this.btnModProdSave_Click);
            // 
            // btnModProdDel
            // 
            this.btnModProdDel.Location = new System.Drawing.Point(723, 438);
            this.btnModProdDel.Name = "btnModProdDel";
            this.btnModProdDel.Size = new System.Drawing.Size(75, 35);
            this.btnModProdDel.TabIndex = 19;
            this.btnModProdDel.Text = "Delete";
            this.btnModProdDel.UseVisualStyleBackColor = true;
            this.btnModProdDel.Click += new System.EventHandler(this.btnModProdDel_Click);
            // 
            // btnModProdAllPartAdd
            // 
            this.btnModProdAllPartAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModProdAllPartAdd.Location = new System.Drawing.Point(723, 219);
            this.btnModProdAllPartAdd.Name = "btnModProdAllPartAdd";
            this.btnModProdAllPartAdd.Size = new System.Drawing.Size(75, 35);
            this.btnModProdAllPartAdd.TabIndex = 20;
            this.btnModProdAllPartAdd.Text = "Add";
            this.btnModProdAllPartAdd.UseVisualStyleBackColor = true;
            this.btnModProdAllPartAdd.Click += new System.EventHandler(this.btnModProdAllPartAdd_Click);
            // 
            // txtBoxSearchModProd
            // 
            this.txtBoxSearchModProd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxSearchModProd.Location = new System.Drawing.Point(638, 36);
            this.txtBoxSearchModProd.Name = "txtBoxSearchModProd";
            this.txtBoxSearchModProd.Size = new System.Drawing.Size(175, 20);
            this.txtBoxSearchModProd.TabIndex = 22;
            this.txtBoxSearchModProd.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // errProvModProdId
            // 
            this.errProvModProdId.ContainerControl = this;
            // 
            // errProvModProdName
            // 
            this.errProvModProdName.ContainerControl = this;
            // 
            // errProvModProdInvent
            // 
            this.errProvModProdInvent.ContainerControl = this;
            // 
            // errProvModProdPrice
            // 
            this.errProvModProdPrice.ContainerControl = this;
            // 
            // errProvModProdMax
            // 
            this.errProvModProdMax.ContainerControl = this;
            // 
            // errProvModProdMin
            // 
            this.errProvModProdMin.ContainerControl = this;
            // 
            // lblSearchModProd
            // 
            this.lblSearchModProd.AutoSize = true;
            this.lblSearchModProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchModProd.Location = new System.Drawing.Point(585, 38);
            this.lblSearchModProd.Name = "lblSearchModProd";
            this.lblSearchModProd.Size = new System.Drawing.Size(47, 13);
            this.lblSearchModProd.TabIndex = 23;
            this.lblSearchModProd.Text = "Search";
            // 
            // prodModIdBottom
            // 
            this.prodModIdBottom.HeaderText = "Id";
            this.prodModIdBottom.Name = "prodModIdBottom";
            this.prodModIdBottom.ReadOnly = true;
            // 
            // prodModNameBottom
            // 
            this.prodModNameBottom.HeaderText = "Name";
            this.prodModNameBottom.Name = "prodModNameBottom";
            this.prodModNameBottom.ReadOnly = true;
            // 
            // prodModInventBottom
            // 
            this.prodModInventBottom.HeaderText = "Inventory";
            this.prodModInventBottom.Name = "prodModInventBottom";
            this.prodModInventBottom.ReadOnly = true;
            // 
            // prodModPriceBottom
            // 
            this.prodModPriceBottom.HeaderText = "Price";
            this.prodModPriceBottom.Name = "prodModPriceBottom";
            this.prodModPriceBottom.ReadOnly = true;
            // 
            // prodModMaxBottom
            // 
            this.prodModMaxBottom.HeaderText = "Max";
            this.prodModMaxBottom.Name = "prodModMaxBottom";
            this.prodModMaxBottom.ReadOnly = true;
            // 
            // prodModMinBottom
            // 
            this.prodModMinBottom.HeaderText = "Min";
            this.prodModMinBottom.Name = "prodModMinBottom";
            this.prodModMinBottom.ReadOnly = true;
            // 
            // machIdModBottom
            // 
            this.machIdModBottom.HeaderText = "Machine Id/Company Name";
            this.machIdModBottom.Name = "machIdModBottom";
            this.machIdModBottom.ReadOnly = true;
            // 
            // productModForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 534);
            this.Controls.Add(this.lblSearchModProd);
            this.Controls.Add(this.txtBoxSearchModProd);
            this.Controls.Add(this.btnModProdAllPartAdd);
            this.Controls.Add(this.btnModProdDel);
            this.Controls.Add(this.btnModProdSave);
            this.Controls.Add(this.btnModProdCancel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblProdModAllParts);
            this.Controls.Add(this.dataGridViewModProdBottom);
            this.Controls.Add(this.dataGridViewModProdTop);
            this.Controls.Add(this.txtBoxModProdMin);
            this.Controls.Add(this.txtBoxModProdMax);
            this.Controls.Add(this.txtBoxModProdPrice);
            this.Controls.Add(this.txtBoxModProdName);
            this.Controls.Add(this.txtBoxModProdInvent);
            this.Controls.Add(this.txtBoxModProdId);
            this.Controls.Add(this.lblModProdMax);
            this.Controls.Add(this.lblModProdMin);
            this.Controls.Add(this.lblModProdPrice);
            this.Controls.Add(this.lblModProdInvent);
            this.Controls.Add(this.lblModProdName);
            this.Controls.Add(this.lblModProdId);
            this.Controls.Add(this.lblModProdTitle);
            this.Name = "productModForm";
            this.Text = "Modify Product";
            this.Load += new System.EventHandler(this.productModForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewModProdTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewModProdBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdInvent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvModProdMin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblModProdTitle;
        private System.Windows.Forms.Label lblModProdId;
        private System.Windows.Forms.Label lblModProdName;
        private System.Windows.Forms.Label lblModProdInvent;
        private System.Windows.Forms.Label lblModProdPrice;
        private System.Windows.Forms.Label lblModProdMin;
        private System.Windows.Forms.Label lblModProdMax;
        private System.Windows.Forms.Label lblProdModAllParts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnModProdCancel;
        private System.Windows.Forms.Button btnModProdSave;
        private System.Windows.Forms.Button btnModProdDel;
        private System.Windows.Forms.Button btnModProdAllPartAdd;
        private System.Windows.Forms.ErrorProvider errProvModProdId;
        private System.Windows.Forms.ErrorProvider errProvModProdName;
        private System.Windows.Forms.ErrorProvider errProvModProdInvent;
        private System.Windows.Forms.ErrorProvider errProvModProdPrice;
        private System.Windows.Forms.ErrorProvider errProvModProdMax;
        private System.Windows.Forms.ErrorProvider errProvModProdMin;
        public System.Windows.Forms.TextBox txtBoxModProdId;
        public System.Windows.Forms.TextBox txtBoxModProdInvent;
        public System.Windows.Forms.TextBox txtBoxModProdName;
        public System.Windows.Forms.TextBox txtBoxModProdPrice;
        public System.Windows.Forms.TextBox txtBoxModProdMax;
        public System.Windows.Forms.TextBox txtBoxModProdMin;
        private System.Windows.Forms.Label lblSearchModProd;
        public System.Windows.Forms.TextBox txtBoxSearchModProd;
        public System.Windows.Forms.DataGridView dataGridViewModProdTop;
        public System.Windows.Forms.DataGridView dataGridViewModProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModIdTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModNameTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModInventTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModPriceTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModMaxTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModMinTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModMachIdTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModIdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModNameBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModInventBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModPriceBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModMaxBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodModMinBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn machIdModBottom;
    }
}