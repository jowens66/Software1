﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareOneProject
{
    public class Product
    {       
        public int ProductID { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int InStock { get; set; }
        public int Min { get; set; }
        public int Max { get; set; }
        public string MachId { get; set; }


        public void SaveDataGridViewState(string productName, prodAddForm prodAdd)
        {
            DataTable dataTable = new DataTable("AssociatedParts");

            // Retrieve the existing columns from dataGridViewModProdBottom
            foreach (DataGridViewColumn column in prodAdd.dataGridViewAddProdBottom.Columns)
            {
                if (column.Visible && !dataTable.Columns.Contains(column.Name))
                {
                    dataTable.Columns.Add(column.Name);
                }
            }

            // Add rows to the DataTable from the dataGridViewAddProdBottom
            foreach (DataGridViewRow row in prodAdd.dataGridViewAddProdBottom.Rows)
            {
                if (!row.IsNewRow)
                {
                    DataRow newRow = dataTable.NewRow();

                    foreach (DataColumn column in dataTable.Columns)
                    {
                        if (row.Cells[column.ColumnName].Value != null)
                        {
                            newRow[column.ColumnName] = row.Cells[column.ColumnName].Value;
                        }
                    }

                    dataTable.Rows.Add(newRow);
                }
            }

            // Create an XML file name based on the productName
            string fileName = productName + ".xml";

            // Save the DataTable to the XML file
            dataTable.WriteXml(fileName);
        }




        public void SaveDataGridViewState2(string productName, productModForm prodMod)
        {
            DataTable dataTable = new DataTable("AssociatedParts");

            // Retrieve the existing columns from dataGridViewModProdBottom
            foreach (DataGridViewColumn column in prodMod.dataGridViewModProdBottom.Columns)
            {
                if (column.Visible && !dataTable.Columns.Contains(column.Name))
                {
                    dataTable.Columns.Add(column.Name);
                }
            }

            // Add rows to the DataTable from the dataGridViewModProdBottom
            foreach (DataGridViewRow row in prodMod.dataGridViewModProdBottom.Rows)
            {
                if (!row.IsNewRow)
                {
                    DataRow newRow = dataTable.NewRow();

                    foreach (DataColumn column in dataTable.Columns)
                    {
                        if (row.Cells[column.ColumnName].Value != null)
                        {
                            newRow[column.ColumnName] = row.Cells[column.ColumnName].Value;
                        }
                    }

                    dataTable.Rows.Add(newRow);
                }
            }

            // Create an XML file name based on the productName
            string fileName = productName + ".xml";

            // Save the DataTable to the XML file
            dataTable.WriteXml(fileName);
        }





        public void addAssociatedPart(prodAddForm prodAdd)
        {
            DataGridViewRow currentRow = prodAdd.dataGridViewAddProdTop.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }

                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot add an empty row");
                }
                else
                {
                    int rowIndex = prodAdd.dataGridViewAddProdBottom.Rows.Add(); // Create a new row in dataGridViewAddProdBottom

                    for (int i = 0; i < prodAdd.dataGridViewAddProdBottom.Columns.Count && i < currentRow.Cells.Count; i++) // Copy cell values from dataGridViewAddProdTop to dataGridViewAddProdBottom
                    {
                        prodAdd.dataGridViewAddProdBottom.Rows[rowIndex].Cells[i].Value = currentRow.Cells[i].Value;
                    }
                }
            }
        }





        public void addAssociatedPart2(productModForm prodMod)
        {
            DataGridViewRow currentRow = prodMod.dataGridViewModProdTop.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }

                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot add an empty row");
                }
                else
                {
                    int rowIndex = prodMod.dataGridViewModProdBottom.Rows.Add(); // Create a new row in dataGridViewAddProdBottom

                    for (int i = 0; i < prodMod.dataGridViewModProdBottom.Columns.Count && i < currentRow.Cells.Count; i++) // Copy cell values from dataGridViewAddProdTop to dataGridViewAddProdBottom
                    {
                        prodMod.dataGridViewModProdBottom.Rows[rowIndex].Cells[i].Value = currentRow.Cells[i].Value;
                    }
                }
            }
        }




        public void removeAssociatedPart(prodAddForm prodAdd)
        {
            DataGridViewRow currentRow = prodAdd.dataGridViewAddProdBottom.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }
                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot Delete an empty row");
                }
                else
                {
                    DialogResult dialogResultDeletePart = MessageBox.Show("Are you sure you want to delete this associated part?", "", MessageBoxButtons.YesNo);

                    if (dialogResultDeletePart == DialogResult.Yes)
                    {
                        int rowIndex = prodAdd.dataGridViewAddProdBottom.CurrentCell.RowIndex;
                        prodAdd.dataGridViewAddProdBottom.Rows.RemoveAt(rowIndex);

                    }
                    else if (dialogResultDeletePart == DialogResult.No)
                    {
                        //Clicking no will just close the box without deleting
                    }
                }
            }
        }


        public void removeAssociatedPart2(productModForm prodMod)
        {
            DataGridViewRow currentRow = prodMod.dataGridViewModProdBottom.SelectedRows[0];

            if (currentRow.Cells.Count > 0)
            {
                bool rowIsEmpty = true;

                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    if (cell.Value != null)
                    {
                        rowIsEmpty = false;
                        break;
                    }
                }
                if (rowIsEmpty)
                {
                    MessageBox.Show("You cannot Delete an empty row");
                }
                else
                {
                    DialogResult dialogResultDeletePart = MessageBox.Show("Are you sure you want to delete this associated part?", "", MessageBoxButtons.YesNo);

                    if (dialogResultDeletePart == DialogResult.Yes)
                    {
                        int rowIndex = prodMod.dataGridViewModProdBottom.CurrentCell.RowIndex;
                        prodMod.dataGridViewModProdBottom.Rows.RemoveAt(rowIndex);

                    }
                    else if (dialogResultDeletePart == DialogResult.No)
                    {
                        //Clicking no will just close the box without deleting
                    }
                }
            }
        }

        public void lookupAssociatedPart(prodAddForm prodAdd)
        {
            string searchTopDgv = prodAdd.textBox1.Text.ToLower();

            foreach (DataGridViewRow row in prodAdd.dataGridViewAddProdTop.Rows) // Check every row in DataGridView1
            {
                if (!row.IsNewRow) //This if statement prevents the "Uncommitted new row cannot be deleted." error
                {
                    row.Visible = false; // Reset row visibility

                    foreach (DataGridViewCell cell in row.Cells) //Filter through each cell in the row that is being checked
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTopDgv)) // Compare the cell data with the user input from text box
                        {
                            row.Visible = true; //The data that matched user input was found, so make the row visible
                            break;
                        }
                    }
                }
            }
        }

        public void lookupModProd(productModForm prodMod)
        {
            string searchTopDgv = prodMod.txtBoxSearchModProd.Text.ToLower();

            foreach (DataGridViewRow row in prodMod.dataGridViewModProdTop.Rows) // Check every row in DataGridView1
            {
                if (!row.IsNewRow) //This if statement prevents the "Uncommitted new row cannot be deleted." error
                {
                    row.Visible = false; // Reset row visibility

                    foreach (DataGridViewCell cell in row.Cells) //Filter through each cell in the row that is being checked
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTopDgv)) // Compare the cell data with the user input from text box
                        {
                            row.Visible = true; //The data that matched user input was found, so make the row visible
                            break;
                        }
                    }
                }
            }
        }       
    }
}
