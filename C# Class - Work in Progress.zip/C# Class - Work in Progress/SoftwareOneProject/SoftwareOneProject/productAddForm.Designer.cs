﻿namespace SoftwareOneProject
{
    partial class prodAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblAddProdTitle = new System.Windows.Forms.Label();
            this.lblAddProd = new System.Windows.Forms.Label();
            this.lblAddProdName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBoxAddProdId = new System.Windows.Forms.TextBox();
            this.txtBoxAddProdName = new System.Windows.Forms.TextBox();
            this.txtBoxAddProdInvent = new System.Windows.Forms.TextBox();
            this.txtBoxAddProdPrice = new System.Windows.Forms.TextBox();
            this.txtBoxAddProdMin = new System.Windows.Forms.TextBox();
            this.txtBoxAddProdMax = new System.Windows.Forms.TextBox();
            this.dataGridViewAddProdTop = new System.Windows.Forms.DataGridView();
            this.partIdAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partNameAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partInventoryAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partPriceAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partMaxAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partMinAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partMachIdAddProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewAddProdBottom = new System.Windows.Forms.DataGridView();
            this.btnAddProdAdd = new System.Windows.Forms.Button();
            this.btnAddProdCancel = new System.Windows.Forms.Button();
            this.btnAddProdSave = new System.Windows.Forms.Button();
            this.btnAddProdDelete = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblAllPartsDgvTop = new System.Windows.Forms.Label();
            this.lblAssocParts = new System.Windows.Forms.Label();
            this.errProvAddProdID = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddProdName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddProdInvent = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddProdPrice = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddProdMax = new System.Windows.Forms.ErrorProvider(this.components);
            this.errProvAddProdMin = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblSearchAllParts = new System.Windows.Forms.Label();
            this.partIdAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.machIdAddProdBottom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddProdTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddProdBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdInvent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdMin)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAddProdTitle
            // 
            this.lblAddProdTitle.AutoSize = true;
            this.lblAddProdTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProdTitle.Location = new System.Drawing.Point(12, 41);
            this.lblAddProdTitle.Name = "lblAddProdTitle";
            this.lblAddProdTitle.Size = new System.Drawing.Size(92, 16);
            this.lblAddProdTitle.TabIndex = 0;
            this.lblAddProdTitle.Text = "Add Product";
            // 
            // lblAddProd
            // 
            this.lblAddProd.AutoSize = true;
            this.lblAddProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProd.Location = new System.Drawing.Point(12, 179);
            this.lblAddProd.Name = "lblAddProd";
            this.lblAddProd.Size = new System.Drawing.Size(20, 13);
            this.lblAddProd.TabIndex = 1;
            this.lblAddProd.Text = "ID";
            // 
            // lblAddProdName
            // 
            this.lblAddProdName.AutoSize = true;
            this.lblAddProdName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProdName.Location = new System.Drawing.Point(12, 222);
            this.lblAddProdName.Name = "lblAddProdName";
            this.lblAddProdName.Size = new System.Drawing.Size(39, 13);
            this.lblAddProdName.TabIndex = 2;
            this.lblAddProdName.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Inventory";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 322);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 365);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Max";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(219, 365);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Min";
            // 
            // txtBoxAddProdId
            // 
            this.txtBoxAddProdId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddProdId.Location = new System.Drawing.Point(78, 177);
            this.txtBoxAddProdId.Name = "txtBoxAddProdId";
            this.txtBoxAddProdId.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAddProdId.TabIndex = 7;
            // 
            // txtBoxAddProdName
            // 
            this.txtBoxAddProdName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddProdName.Location = new System.Drawing.Point(78, 220);
            this.txtBoxAddProdName.Name = "txtBoxAddProdName";
            this.txtBoxAddProdName.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAddProdName.TabIndex = 8;
            // 
            // txtBoxAddProdInvent
            // 
            this.txtBoxAddProdInvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddProdInvent.Location = new System.Drawing.Point(78, 269);
            this.txtBoxAddProdInvent.Name = "txtBoxAddProdInvent";
            this.txtBoxAddProdInvent.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAddProdInvent.TabIndex = 9;
            // 
            // txtBoxAddProdPrice
            // 
            this.txtBoxAddProdPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddProdPrice.Location = new System.Drawing.Point(78, 320);
            this.txtBoxAddProdPrice.Name = "txtBoxAddProdPrice";
            this.txtBoxAddProdPrice.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAddProdPrice.TabIndex = 10;
            // 
            // txtBoxAddProdMin
            // 
            this.txtBoxAddProdMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddProdMin.Location = new System.Drawing.Point(249, 363);
            this.txtBoxAddProdMin.Name = "txtBoxAddProdMin";
            this.txtBoxAddProdMin.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAddProdMin.TabIndex = 11;
            // 
            // txtBoxAddProdMax
            // 
            this.txtBoxAddProdMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAddProdMax.Location = new System.Drawing.Point(78, 363);
            this.txtBoxAddProdMax.Name = "txtBoxAddProdMax";
            this.txtBoxAddProdMax.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAddProdMax.TabIndex = 12;
            // 
            // dataGridViewAddProdTop
            // 
            this.dataGridViewAddProdTop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAddProdTop.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.partIdAddProd,
            this.partNameAddProd,
            this.partInventoryAddProd,
            this.partPriceAddProd,
            this.partMaxAddProd,
            this.partMinAddProd,
            this.partMachIdAddProd});
            this.dataGridViewAddProdTop.Location = new System.Drawing.Point(408, 66);
            this.dataGridViewAddProdTop.Name = "dataGridViewAddProdTop";
            this.dataGridViewAddProdTop.ReadOnly = true;
            this.dataGridViewAddProdTop.RowHeadersVisible = false;
            this.dataGridViewAddProdTop.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAddProdTop.Size = new System.Drawing.Size(380, 150);
            this.dataGridViewAddProdTop.TabIndex = 13;
            // 
            // partIdAddProd
            // 
            this.partIdAddProd.HeaderText = "Part Id";
            this.partIdAddProd.Name = "partIdAddProd";
            this.partIdAddProd.ReadOnly = true;
            // 
            // partNameAddProd
            // 
            this.partNameAddProd.HeaderText = "Name";
            this.partNameAddProd.Name = "partNameAddProd";
            this.partNameAddProd.ReadOnly = true;
            // 
            // partInventoryAddProd
            // 
            this.partInventoryAddProd.HeaderText = "Inventory";
            this.partInventoryAddProd.Name = "partInventoryAddProd";
            this.partInventoryAddProd.ReadOnly = true;
            // 
            // partPriceAddProd
            // 
            this.partPriceAddProd.HeaderText = "Price";
            this.partPriceAddProd.Name = "partPriceAddProd";
            this.partPriceAddProd.ReadOnly = true;
            // 
            // partMaxAddProd
            // 
            this.partMaxAddProd.HeaderText = "Max";
            this.partMaxAddProd.Name = "partMaxAddProd";
            this.partMaxAddProd.ReadOnly = true;
            // 
            // partMinAddProd
            // 
            this.partMinAddProd.HeaderText = "Min";
            this.partMinAddProd.Name = "partMinAddProd";
            this.partMinAddProd.ReadOnly = true;
            // 
            // partMachIdAddProd
            // 
            this.partMachIdAddProd.HeaderText = "Machine Id/Company Name";
            this.partMachIdAddProd.Name = "partMachIdAddProd";
            this.partMachIdAddProd.ReadOnly = true;
            // 
            // dataGridViewAddProdBottom
            // 
            this.dataGridViewAddProdBottom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAddProdBottom.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.partIdAddProdBottom,
            this.nameAddProdBottom,
            this.inventAddProdBottom,
            this.priceAddProdBottom,
            this.MaxAddProdBottom,
            this.minAddProdBottom,
            this.machIdAddProdBottom});
            this.dataGridViewAddProdBottom.Location = new System.Drawing.Point(408, 295);
            this.dataGridViewAddProdBottom.Name = "dataGridViewAddProdBottom";
            this.dataGridViewAddProdBottom.ReadOnly = true;
            this.dataGridViewAddProdBottom.RowHeadersVisible = false;
            this.dataGridViewAddProdBottom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAddProdBottom.Size = new System.Drawing.Size(380, 150);
            this.dataGridViewAddProdBottom.TabIndex = 14;
            // 
            // btnAddProdAdd
            // 
            this.btnAddProdAdd.Location = new System.Drawing.Point(699, 222);
            this.btnAddProdAdd.Name = "btnAddProdAdd";
            this.btnAddProdAdd.Size = new System.Drawing.Size(75, 33);
            this.btnAddProdAdd.TabIndex = 15;
            this.btnAddProdAdd.Text = "Add";
            this.btnAddProdAdd.UseVisualStyleBackColor = true;
            this.btnAddProdAdd.Click += new System.EventHandler(this.btnAddProdAdd_Click);
            // 
            // btnAddProdCancel
            // 
            this.btnAddProdCancel.Location = new System.Drawing.Point(699, 507);
            this.btnAddProdCancel.Name = "btnAddProdCancel";
            this.btnAddProdCancel.Size = new System.Drawing.Size(75, 33);
            this.btnAddProdCancel.TabIndex = 16;
            this.btnAddProdCancel.Text = "Cancel";
            this.btnAddProdCancel.UseVisualStyleBackColor = true;
            this.btnAddProdCancel.Click += new System.EventHandler(this.btnAddProdCancel_Click);
            // 
            // btnAddProdSave
            // 
            this.btnAddProdSave.Location = new System.Drawing.Point(618, 507);
            this.btnAddProdSave.Name = "btnAddProdSave";
            this.btnAddProdSave.Size = new System.Drawing.Size(75, 33);
            this.btnAddProdSave.TabIndex = 17;
            this.btnAddProdSave.Text = "Save";
            this.btnAddProdSave.UseVisualStyleBackColor = true;
            this.btnAddProdSave.Click += new System.EventHandler(this.btnAddProdSave_Click);
            // 
            // btnAddProdDelete
            // 
            this.btnAddProdDelete.Location = new System.Drawing.Point(699, 460);
            this.btnAddProdDelete.Name = "btnAddProdDelete";
            this.btnAddProdDelete.Size = new System.Drawing.Size(75, 31);
            this.btnAddProdDelete.TabIndex = 18;
            this.btnAddProdDelete.Text = "Delete";
            this.btnAddProdDelete.UseVisualStyleBackColor = true;
            this.btnAddProdDelete.Click += new System.EventHandler(this.btnAddProdDelete_Click);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(593, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(195, 20);
            this.textBox1.TabIndex = 20;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblAllPartsDgvTop
            // 
            this.lblAllPartsDgvTop.AutoSize = true;
            this.lblAllPartsDgvTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAllPartsDgvTop.Location = new System.Drawing.Point(408, 50);
            this.lblAllPartsDgvTop.Name = "lblAllPartsDgvTop";
            this.lblAllPartsDgvTop.Size = new System.Drawing.Size(54, 13);
            this.lblAllPartsDgvTop.TabIndex = 21;
            this.lblAllPartsDgvTop.Text = "All Parts";
            // 
            // lblAssocParts
            // 
            this.lblAssocParts.AutoSize = true;
            this.lblAssocParts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssocParts.Location = new System.Drawing.Point(408, 276);
            this.lblAssocParts.Name = "lblAssocParts";
            this.lblAssocParts.Size = new System.Drawing.Size(199, 13);
            this.lblAssocParts.TabIndex = 22;
            this.lblAssocParts.Text = "Parts Associated with the Product";
            // 
            // errProvAddProdID
            // 
            this.errProvAddProdID.ContainerControl = this;
            // 
            // errProvAddProdName
            // 
            this.errProvAddProdName.ContainerControl = this;
            // 
            // errProvAddProdInvent
            // 
            this.errProvAddProdInvent.ContainerControl = this;
            // 
            // errProvAddProdPrice
            // 
            this.errProvAddProdPrice.ContainerControl = this;
            // 
            // errProvAddProdMax
            // 
            this.errProvAddProdMax.ContainerControl = this;
            // 
            // errProvAddProdMin
            // 
            this.errProvAddProdMin.ContainerControl = this;
            // 
            // lblSearchAllParts
            // 
            this.lblSearchAllParts.AutoSize = true;
            this.lblSearchAllParts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchAllParts.Location = new System.Drawing.Point(540, 39);
            this.lblSearchAllParts.Name = "lblSearchAllParts";
            this.lblSearchAllParts.Size = new System.Drawing.Size(47, 13);
            this.lblSearchAllParts.TabIndex = 23;
            this.lblSearchAllParts.Text = "Search";
            // 
            // partIdAddProdBottom
            // 
            this.partIdAddProdBottom.HeaderText = "Part Id";
            this.partIdAddProdBottom.Name = "partIdAddProdBottom";
            this.partIdAddProdBottom.ReadOnly = true;
            // 
            // nameAddProdBottom
            // 
            this.nameAddProdBottom.HeaderText = "Name";
            this.nameAddProdBottom.Name = "nameAddProdBottom";
            this.nameAddProdBottom.ReadOnly = true;
            // 
            // inventAddProdBottom
            // 
            this.inventAddProdBottom.HeaderText = "Inventory";
            this.inventAddProdBottom.Name = "inventAddProdBottom";
            this.inventAddProdBottom.ReadOnly = true;
            // 
            // priceAddProdBottom
            // 
            this.priceAddProdBottom.HeaderText = "Price";
            this.priceAddProdBottom.Name = "priceAddProdBottom";
            this.priceAddProdBottom.ReadOnly = true;
            // 
            // MaxAddProdBottom
            // 
            this.MaxAddProdBottom.HeaderText = "Max";
            this.MaxAddProdBottom.Name = "MaxAddProdBottom";
            this.MaxAddProdBottom.ReadOnly = true;
            // 
            // minAddProdBottom
            // 
            this.minAddProdBottom.HeaderText = "Min";
            this.minAddProdBottom.Name = "minAddProdBottom";
            this.minAddProdBottom.ReadOnly = true;
            // 
            // machIdAddProdBottom
            // 
            this.machIdAddProdBottom.HeaderText = "Machine Id/Company Name";
            this.machIdAddProdBottom.Name = "machIdAddProdBottom";
            this.machIdAddProdBottom.ReadOnly = true;
            // 
            // prodAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 554);
            this.Controls.Add(this.lblSearchAllParts);
            this.Controls.Add(this.lblAssocParts);
            this.Controls.Add(this.lblAllPartsDgvTop);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnAddProdDelete);
            this.Controls.Add(this.btnAddProdSave);
            this.Controls.Add(this.btnAddProdCancel);
            this.Controls.Add(this.btnAddProdAdd);
            this.Controls.Add(this.dataGridViewAddProdBottom);
            this.Controls.Add(this.dataGridViewAddProdTop);
            this.Controls.Add(this.txtBoxAddProdMax);
            this.Controls.Add(this.txtBoxAddProdMin);
            this.Controls.Add(this.txtBoxAddProdPrice);
            this.Controls.Add(this.txtBoxAddProdInvent);
            this.Controls.Add(this.txtBoxAddProdName);
            this.Controls.Add(this.txtBoxAddProdId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblAddProdName);
            this.Controls.Add(this.lblAddProd);
            this.Controls.Add(this.lblAddProdTitle);
            this.Name = "prodAddForm";
            this.Text = "Add Product";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.prodAddForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.prodAddForm_FormClosed);
            this.Load += new System.EventHandler(this.prodAddForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddProdTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddProdBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdInvent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvAddProdMin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddProdTitle;
        private System.Windows.Forms.Label lblAddProd;
        private System.Windows.Forms.Label lblAddProdName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBoxAddProdId;
        private System.Windows.Forms.TextBox txtBoxAddProdName;
        private System.Windows.Forms.TextBox txtBoxAddProdInvent;
        private System.Windows.Forms.TextBox txtBoxAddProdPrice;
        private System.Windows.Forms.TextBox txtBoxAddProdMin;
        private System.Windows.Forms.TextBox txtBoxAddProdMax;
        public System.Windows.Forms.DataGridView dataGridViewAddProdTop;
        public System.Windows.Forms.DataGridView dataGridViewAddProdBottom;
        private System.Windows.Forms.Button btnAddProdAdd;
        private System.Windows.Forms.Button btnAddProdCancel;
        private System.Windows.Forms.Button btnAddProdSave;
        private System.Windows.Forms.Button btnAddProdDelete;
        private System.Windows.Forms.Label lblAllPartsDgvTop;
        private System.Windows.Forms.Label lblAssocParts;
        private System.Windows.Forms.ErrorProvider errProvAddProdID;
        private System.Windows.Forms.ErrorProvider errProvAddProdName;
        private System.Windows.Forms.ErrorProvider errProvAddProdInvent;
        private System.Windows.Forms.ErrorProvider errProvAddProdPrice;
        private System.Windows.Forms.ErrorProvider errProvAddProdMax;
        private System.Windows.Forms.ErrorProvider errProvAddProdMin;
        private System.Windows.Forms.DataGridViewTextBoxColumn partIdAddProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn partNameAddProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn partInventoryAddProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn partPriceAddProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn partMaxAddProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn partMinAddProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn partMachIdAddProd;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblSearchAllParts;
        private System.Windows.Forms.DataGridViewTextBoxColumn partIdAddProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameAddProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventAddProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceAddProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxAddProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn minAddProdBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn machIdAddProdBottom;
    }
}