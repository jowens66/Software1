﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareOneProject
{
    public partial class partAddForm : Form
    {
        mainForm mform { get; set; } = new mainForm(); //Possible stack overflow exception       
        

        public partAddForm(mainForm mf)
        {
            InitializeComponent();
            this.mform = mf;
            
        }

        public partAddForm()
        {
        }

        private void btnCancelAddPart_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void btnSveAddPart_Click(object sender, EventArgs e)
        {
            Inventory inventory = new Inventory();
            int partIDResult;
            int partInventResult;
            int partMaxResult;
            int partMinResult;
            int partMachIdResult;          

            string namePattern = "^[a-zA-Z]+(\\s[a-zA-Z]+)?$";
            string compPattern = "^[a-zA-Z]+(\\s[a-zA-Z]+)?$";
            string pricePattern = "[0-9]+\\.?[0-9,]*";

            bool isNameValid = Regex.IsMatch(txtBoxAddPartName.Text, namePattern);
            bool isCompValid = Regex.IsMatch(txtBoxAddPartMachId.Text, compPattern);
            bool isPriceValid = Regex.IsMatch(txtBoxAddPartPrice.Text, pricePattern);

            if (string.IsNullOrEmpty(txtBoxAddPartId.Text)) //Validation for add part ID
            {
                errProvAddPartId.SetError(txtBoxAddPartId, "Part ID is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddPartId.Text, out partIDResult))
            {
                errProvAddPartId.SetError(txtBoxAddPartId, "Part ID must be a whole number");
                return;
            }
            else
            {
                errProvAddPartId.SetError(txtBoxAddPartId, string.Empty);
            }
            


            if (string.IsNullOrEmpty(txtBoxAddPartName.Text)) //Validation for add part Name
            {
                errProvAddPartName.SetError(txtBoxAddPartName, "Part Name is required");
                return;
            }
            else if (!isNameValid)
            {
                errProvAddPartName.SetError(txtBoxAddPartName, "Part Name must only be letters");
                return;
            }
            else
            {
                errProvAddPartName.SetError(txtBoxAddPartName, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddPartInvent.Text)) //Validation for add part Inventory
            {
                errProvAddPartInvent.SetError(txtBoxAddPartInvent, "Part Inventory is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddPartInvent.Text, out partInventResult))
            {
                errProvAddPartInvent.SetError(txtBoxAddPartInvent, "Inventory must be a whole number");
                return;
            }           
            else
            {
                errProvAddPartInvent.SetError(txtBoxAddPartInvent, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddPartPrice.Text)) //Validation for add part Price
            {
                errProvAddPartPrice.SetError(txtBoxAddPartPrice, "Part Price is required");
                return;
            }
            else if (!isPriceValid)
            {
                errProvAddPartPrice.SetError(txtBoxAddPartPrice, "Price amount must be a decimal or use a comma");
                return;
            }
            else
            {
                errProvAddPartPrice.SetError(txtBoxAddPartPrice, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddPartMax.Text)) //Validation for add part Max
            {
                errProvAddPartMax.SetError(txtBoxAddPartMax, "Part Max is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddPartMax.Text, out partMaxResult))
            {
                errProvAddPartMax.SetError(txtBoxAddPartMax, "Part Max must be a whole number");
                return;
            }
            else if (partInventResult > partMaxResult)
            {
                errProvAddPartInvent.SetError(txtBoxAddPartInvent, "Part Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvAddPartMax.SetError(txtBoxAddPartMax, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxAddPartMin.Text)) //Validation for add part Min
            {
                errProvAddPartMin.SetError(txtBoxAddPartMin, "Part Min is required");
                return;
            }
            else if (!int.TryParse(txtBoxAddPartMin.Text, out partMinResult))
            {
                errProvAddPartMin.SetError(txtBoxAddPartMin, "Part Min must be a whole number");
                return;
            }
            else if (partMinResult >= partMaxResult)
            {
                errProvAddPartMin.SetError(txtBoxAddPartMin, "Part Min must be lower than part Max"); //Validate that Min is lower than Max  THIS DOES NOT WORK
                return;
            }
            else if (partInventResult < partMinResult)
            {
                errProvAddPartInvent.SetError(txtBoxAddPartInvent, "Part Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvAddPartMin.SetError(txtBoxAddPartMin, string.Empty);
            }

            if (!rdoBtnOutSAdd.Checked)
            {

                if (string.IsNullOrEmpty(txtBoxAddPartMachId.Text)) //Validation for add part Machine Id
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, "Part Machine ID is required");
                    return;
                }
                else if (!int.TryParse(txtBoxAddPartMachId.Text, out partMachIdResult))
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, "Machine ID must be a whole number");        //FIXED. Issue was the nested if and needing to make unique Regex
                    return;
                }
                else
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, string.Empty);
                }
            }

            if (rdoBtnInHAdd.Checked)
            {
                inventory.IsInHouse = true;
                // Create and handle InHouse part
            }
            else // rdoBtnOutSAdd.Checked
            {
                inventory.IsInHouse = false;
                // Create and handle Outsourced part
            }

            Part partP = new Part();
            if (rdoBtnInHAdd.Checked)
            {
                if (string.IsNullOrEmpty(txtBoxAddPartMachId.Text))
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, "Machine ID is required");
                    return;
                }

                if (!int.TryParse(txtBoxAddPartMachId.Text, out int machineIDResult))
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, "Machine ID must be a whole number");
                    return;
                }

                partP = new InHouse
                {
                    partId = int.Parse(txtBoxAddPartId.Text),
                    PartName = txtBoxAddPartName.Text,
                    partInvent = int.Parse(txtBoxAddPartInvent.Text),
                    partPrice = decimal.Parse(txtBoxAddPartPrice.Text),
                    partMax = int.Parse(txtBoxAddPartMax.Text),
                    partMin = int.Parse(txtBoxAddPartMin.Text),
                    MachineID = machineIDResult
                };
            }
            else
            {
                if (string.IsNullOrEmpty(txtBoxAddPartMachId.Text))
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, "Company Name is required");
                    return;
                }
                else if (!isCompValid)
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, "Company Name must only be letters");
                    return;
                }
                else
                {
                    errProvAddPartMachId.SetError(txtBoxAddPartMachId, string.Empty);
                }

                partP = new Outsourced
                {
                    partId = int.Parse(txtBoxAddPartId.Text),
                    PartName = txtBoxAddPartName.Text,
                    partInvent = int.Parse(txtBoxAddPartInvent.Text),
                    partPrice = decimal.Parse(txtBoxAddPartPrice.Text),
                    partMax = int.Parse(txtBoxAddPartMax.Text),
                    partMin = int.Parse(txtBoxAddPartMin.Text),
                    CompanyName = txtBoxAddPartMachId.Text
                };
            }

            
            inventory.addPart(partP, mform);

            this.Close();
        }



        private void rdoBtnInHAdd_CheckedChanged(object sender, EventArgs e)
        {
            lblMachIdAddPart.Text = "Machine ID";
        }

        private void rdoBtnOutSAdd_CheckedChanged(object sender, EventArgs e)
        {
            lblMachIdAddPart.Text = "Company Name";
        }

        
    }
}
