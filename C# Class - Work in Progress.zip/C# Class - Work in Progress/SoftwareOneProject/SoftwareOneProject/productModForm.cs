﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace SoftwareOneProject
{
    public partial class productModForm : Form
    {
        private mainForm mform;
        Product addProd = new Product();   

        public productModForm(mainForm mf)
        {
            InitializeComponent();
            this.mform = mf;          
        }              

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModProdSave_Click(object sender, EventArgs e)
        {
            int prodIDResult;
            int prodInventResult;
            int prodMaxResult;
            int prodMinResult;          

            string namePattern = "^[a-zA-Z]+(\\s[a-zA-Z]+)?$";
            string pricePattern = "[0-9]+\\.?[0-9,]*";

            bool isNameValid = Regex.IsMatch(txtBoxModProdName.Text, namePattern);
            bool isPriceValid = Regex.IsMatch(txtBoxModProdPrice.Text, pricePattern);

            if (string.IsNullOrEmpty(txtBoxModProdId.Text)) //Validation for mod product ID
            {
                errProvModProdId.SetError(txtBoxModProdId, "Product ID is required");
                return;
            }
            else if (!int.TryParse(txtBoxModProdId.Text, out prodIDResult))
            {
                errProvModProdId.SetError(txtBoxModProdId, "Product ID must be a whole number");
                return;
            }
            else
            {
                errProvModProdId.SetError(txtBoxModProdId, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModProdName.Text)) //Validation for mod product Name
            {
                errProvModProdName.SetError(txtBoxModProdName, "Product Name is required");
                return;
            }
            else if (!isNameValid)
            {
                errProvModProdName.SetError(txtBoxModProdName, "Product Name must only be letters");
                return;
            }
            else
            {
                errProvModProdName.SetError(txtBoxModProdName, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModProdInvent.Text)) //Validation for mod product Inventory
            {
                errProvModProdInvent.SetError(txtBoxModProdInvent, "Product Inventory is required");
                return;
            }
            else if (!int.TryParse(txtBoxModProdInvent.Text, out prodInventResult))
            {
                errProvModProdInvent.SetError(txtBoxModProdInvent, "Inventory must be a whole number");
                return;
            }
            else
            {
                errProvModProdInvent.SetError(txtBoxModProdInvent, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModProdPrice.Text)) //Validation for mod product Price
            {
                errProvModProdPrice.SetError(txtBoxModProdPrice, "Product Price is required");
                return;
            }
            else if (!isPriceValid)
            {
                errProvModProdPrice.SetError(txtBoxModProdPrice, "Price amount must be a decimal or use a comma");
                return;
            }
            else
            {
                errProvModProdPrice.SetError(txtBoxModProdPrice, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModProdMax.Text)) //Validation for mod product Max
            {
                errProvModProdMax.SetError(txtBoxModProdMax, "Product Max is required");
                return;
            }
            else if (!int.TryParse(txtBoxModProdMax.Text, out prodMaxResult))
            {
                errProvModProdMax.SetError(txtBoxModProdMax, "Product Max must be a whole number");
                return;
            }
            else if (prodInventResult > prodMaxResult)
            {
                errProvModProdInvent.SetError(txtBoxModProdInvent, "Product Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvModProdMax.SetError(txtBoxModProdMax, string.Empty);
            }



            if (string.IsNullOrEmpty(txtBoxModProdMin.Text)) //Validation for mod product Min
            {
                errProvModProdMin.SetError(txtBoxModProdMin, "Product Min is required");
                return;
            }
            else if (!int.TryParse(txtBoxModProdMin.Text, out prodMinResult))
            {
                errProvModProdMin.SetError(txtBoxModProdMin, "Product Min must be a whole number");
                return;
            }
            else if (prodMinResult >= prodMaxResult)
            {
                errProvModProdMin.SetError(txtBoxModProdMin, "Product Min must be lower than part Max"); //Validate that Min is lower than Max
                return;
            }
            else if (prodInventResult < prodMinResult)
            {
                errProvModProdInvent.SetError(txtBoxModProdInvent, "Product Inventory must be a between Max and Min");
                return;
            }
            else
            {
                errProvModProdMin.SetError(txtBoxModProdMin, string.Empty);
            }

            mform.dataGridView2.CurrentRow.Cells[0].Value = txtBoxModProdId.Text; //THIS IS IT!!!! The Code that allows you to modify the Datagridview
            mform.dataGridView2.CurrentRow.Cells[1].Value = txtBoxModProdName.Text;
            mform.dataGridView2.CurrentRow.Cells[2].Value = txtBoxModProdInvent.Text;
            mform.dataGridView2.CurrentRow.Cells[3].Value = txtBoxModProdPrice.Text;
            mform.dataGridView2.CurrentRow.Cells[4].Value = txtBoxModProdMax.Text;
            mform.dataGridView2.CurrentRow.Cells[5].Value = txtBoxModProdMin.Text;

            addProd.SaveDataGridViewState2(txtBoxModProdName.Text, this);

            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            addProd.lookupModProd(this);
        }

        private void btnModProdAllPartAdd_Click(object sender, EventArgs e)
        {
            addProd.addAssociatedPart2(this);
        }

        private void btnModProdDel_Click(object sender, EventArgs e)
        {                        
            addProd.removeAssociatedPart2(this);      
        }     
        private void productModForm_Load(object sender, EventArgs e)
        {
            
        }
        public void LoadXmlData(string xmlFilePath)
        {
            if (File.Exists(xmlFilePath))
            {
                DataSet dataSet = new DataSet();
                dataSet.ReadXml(xmlFilePath); // Read the XML file into a DataSet

                if (dataSet.Tables.Count > 0)
                {
                    DataTable dataTable = dataSet.Tables[0];

                    // Clear the existing columns and rows in dataGridViewModProdBottom
                    dataGridViewModProdBottom.Columns.Clear();
                    dataGridViewModProdBottom.Rows.Clear();

                    // Add columns to dataGridViewModProdBottom with custom header text
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        // Replace the column name with your desired header text
                        string headerText = GetHeaderText(column.ColumnName);
                        dataGridViewModProdBottom.Columns.Add(column.ColumnName, headerText);
                    }

                    // Add rows to dataGridViewModProdBottom based on the DataTable
                    foreach (DataRow row in dataTable.Rows)
                    {
                        dataGridViewModProdBottom.Rows.Add(row.ItemArray);
                    }
                }
            }
        }

        // Custom method to get the desired header text for a column name
        private string GetHeaderText(string columnName)
        {
            // You can implement your logic here to map column names to desired header text
            // Example mapping: "partIdAddProdBottom" => "Part ID"
            if (columnName == "prodModIdBottom")
            {
                return "Part ID";
            }
            else if(columnName == "partIdAddProdBottom")
            {
                return "Part ID";
            }
            if (columnName == "prodModNameBottom")
            {
                return "Name";
            }
            else if (columnName == "nameAddProdBottom")
            {
                return "Name";
            }
            if (columnName == "prodModInventBottom")
            {
                return "Inventory";
            }
            else if (columnName == "inventAddProdBottom")
            {
                return "Inventory";
            }
            if (columnName == "prodModPriceBottom")
            {
                return "Price";
            }
            else if (columnName == "priceAddProdBottom")
            {
                return "Price";
            }
            if (columnName == "prodModMaxBottom")
            {
                return "Max";
            }
            else if (columnName == "MaxAddProdBottom")
            {
                return "Max";
            }
            if ( columnName == "prodModMinBottom")
            {
                return "Min";
            }
            else if (columnName == "minAddProdBottom")
            {
                return "Min";
            }
            if (columnName == "machIdModBottom")
            {
                return "Machine Id/Company Name";
            }
            else if (columnName == "machIdAddProdBottom")
            {
                return "Machine Id/Company Name";
            }

            // Default case: return the column name itself as the header text
            return columnName;
        }



    }
}
